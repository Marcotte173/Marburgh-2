﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum SkillType {Spell,Head,Legs,Axe,Bow,Dagger,GreatAxe,GreatSword,Fist,Shield,Sword }
[CreateAssetMenu(fileName = "Data", menuName = "Skill", order = 1)]
public class Skill : ScriptableObject
{
    public SkillType type;
    public bool playerOnly;
    public string skillName;
    public string actionName;    
    public int level;
    public int toHit;
    public int familiarityRequired;
    public int coordinationRequired;
    public bool requireTwoHand;
    public bool blockable;
    public bool cast;
    public bool passive;
    public int range;
    public int priority;
    public int magnitude;
    public List<string> text;
}
