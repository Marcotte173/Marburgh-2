using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MonsterList : MonoBehaviour
{
    public static MonsterList instance;
    public List<Agent> human1;
    public List<Agent> boss;
    public List<Agent> subBoss;
    public List<Drop> bossKeys; 
    private void Start()
    {
        instance = this;
    }   
}
