﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemList : MonoBehaviour
{
    public static ItemList instance;

    private void Start()
    {
        instance = this;
        leftFist = Instantiate(leftFist);
        leftFist.name = "Left Fist";
        rightFist = Instantiate(rightFist);
        rightFist.name = "Right Fist";
        Formulas.SetArmorValues();
    }    

    public Drop bookOfFlame;
    public Weapon rightFist;
    public Weapon leftFist;
    public Weapon rock;
    public Weapon dagger;
    public Weapon bow;
    public Weapon sword;
    public Weapon greatSword;
    public Weapon axe;
    public Weapon greatAxe;
    public Weapon roundShield;
    public Weapon twoHand;
    public Armor none;
    public List<Armor> clothArmor;
    public List<Armor> leatherArmor;
    public List<Armor> butcherArmor;
    public Drop gold;
    public Terrain fountain;
    public Terrain shopKeeper;
    public List<Weapon> shopWeapon1;
    public List<Armor> shopArmor1;
    public List<Drop> shopDrop1;
    public Drop sell;
    public void InstantiateDrop(Drop droptoInstatiate)
    {
        Drop d = Instantiate(droptoInstatiate);
        d.name = droptoInstatiate.name;
        d.dropName = droptoInstatiate.dropName+"Plop";
        droptoInstatiate = d;
    }    
}
