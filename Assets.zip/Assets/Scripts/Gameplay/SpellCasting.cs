using System.Collections;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SpellCasting : MonoBehaviour
{
    public List<Skill> spell;
    public GameObject castObject;
    public Button castButton;
    public List<Sprite> flameSprite;
    
    public void Flame()
    {        
        Agent attacker = GetComponent<Agent>();
        Agent defender = attacker.target;
        if (spell.Count == 1)
        {
            CombatLog.instance.UpdateLog($"{defender.agentName} is engulfed in flames!");
            Formulas.Target(defender, spell[0]).TakeDamage(Formulas.Damage(attacker, spell[0]), true);
            Instantiate(FX.instance.explosion, defender.transform.position, Quaternion.identity);
        }
        if (spell.Count == 2)
        {
            CombatLog.instance.UpdateLog($"{defender.agentName} is engulfed in flames!");
            CombatLog.instance.UpdateLog($"{defender.agentName} is on fire!");
            Formulas.Target(defender, spell[0]).TakeDamage(Formulas.Damage(attacker, spell[0]), true);
            defender.onFire = 3;
            defender.fireDamage = Return.Int(4, 9 + 1) + attacker.head.intelligence / 2;
            Instantiate(FX.instance.explosion, defender.transform.position, Quaternion.identity);
        }
        if (spell.Count == 3)
        {
            CombatLog.instance.UpdateLog($"Flames engulf everyone in the room!");
            foreach (Agent a in Dungeon.instance.currentFloor.currentRoom.agentList.ToList())
            {
                if (a!= GameManager.instance.player)
                {
                    Formulas.Target(defender, spell[0]).TakeDamage(Formulas.Damage(attacker, spell[0]), true);
                    Instantiate(FX.instance.explosion, a.transform.position, Quaternion.identity);
                }                
            }
        }        
        attacker.StopCasting();
    }

    public void Cast()
    {
        if (spell[0].actionName.Contains("Flame")) Flame();
        GameManager.instance.EndTurn();
    }
}
