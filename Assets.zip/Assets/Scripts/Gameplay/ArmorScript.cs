﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public enum ArmorType { None, Cloth, Leather, Mail, Plate }
public class ArmorScript : MonoBehaviour
{
    public ArmorType type;
    public Status status;
    public Body body;
    public int value;
    public int maxHp;
    public int hp;
    public string armorName;
    public Sprite pic;
    public Image paperDoll;
    
    public void UpdateArmor()
    {
        if (status != Status.Destroyed) GetComponent<SpriteRenderer>().sprite = pic;
        else
        {
            GetComponent<SpriteRenderer>().sprite = ItemList.instance.none.sprite;
            if (body == GameManager.instance.player.head) GameManager.instance.player.player.inventory[8].armor = null;
            if (body == GameManager.instance.player.body) GameManager.instance.player.player.inventory[9].armor = null;
            if (body == GameManager.instance.player.leftArm) GameManager.instance.player.player.inventory[10].armor = null;
            if (body == GameManager.instance.player.rightArm) GameManager.instance.player.player.inventory[11].armor = null;
            if (body == GameManager.instance.player.legs) GameManager.instance.player.player.inventory[12].armor = null;
            GameManager.instance.ArmorEquip();
        }        
        if (body.source.player != null)
        {
            paperDoll.sprite = GetComponent<SpriteRenderer>().sprite;
        }
        if (type == ArmorType.None)
        {
            armorName = "";
        }
        else
        {
            status = Return.TheStatus(hp, maxHp);
            armorName = Return.Item(body.bodyType, type);
        }        
    }
    public void Equip(Armor a)
    {
        pic  = a.sprite;
        armorName = a.armorName;
        type = a.type;
        hp = a.hp;
        maxHp = a.maxHp;
        value = a.value;
        GetComponent<SpriteRenderer>().sprite = pic;
    }
}
