﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum Handed { One, Two };

[CreateAssetMenu(fileName = "Data", menuName = "Weapon", order = 1)]
public class Weapon : ScriptableObject
{
    public Handed handed;
    public int range;
    public int damage;
    public int value;
    public string weaponName;
    public List<Skill> availableActions;
    public Sprite sprite;
    public bool shop;
    public List<string> description;
}