﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Formulas
{
    public static void DetermineHealth()
    {
        foreach (Agent h in MonsterList.instance.human1)
        {
            h.head.hp = h.head.maxHp =                                                                 8  * GameManager.instance.healthRatio / 10;
            h.body.hp = h.body.maxHp =                                                                 20 * GameManager.instance.healthRatio / 10;
            h.leftArm.hp = h.leftArm.maxHp =                                                           12 * GameManager.instance.healthRatio / 10;
            h.rightArm.hp = h.rightArm.maxHp =                                                         12 * GameManager.instance.healthRatio / 10;
            h.legs.hp = h.legs.maxHp =                                                                 15 * GameManager.instance.healthRatio / 10;
        }

        MonsterList.instance.boss[0].head.hp = MonsterList.instance.boss[0].head.maxHp =               1 * GameManager.instance.healthRatio / 10;
        MonsterList.instance.boss[0].body.hp = MonsterList.instance.boss[0].body.maxHp =               1 * GameManager.instance.healthRatio / 10;
        MonsterList.instance.boss[0].leftArm.hp = MonsterList.instance.boss[0].leftArm.maxHp =         1 * GameManager.instance.healthRatio / 10;
        MonsterList.instance.boss[0].rightArm.hp = MonsterList.instance.boss[0].rightArm.maxHp =       1 * GameManager.instance.healthRatio / 10;
        MonsterList.instance.boss[0].legs.hp = MonsterList.instance.boss[0].legs.maxHp =               1 * GameManager.instance.healthRatio / 10;

        MonsterList.instance.subBoss[0].head.hp = MonsterList.instance.subBoss[0].head.maxHp =         1 * GameManager.instance.healthRatio / 10;
        MonsterList.instance.subBoss[0].body.hp = MonsterList.instance.subBoss[0].body.maxHp =         1 * GameManager.instance.healthRatio / 10;
        MonsterList.instance.subBoss[0].leftArm.hp = MonsterList.instance.subBoss[0].leftArm.maxHp =   1 * GameManager.instance.healthRatio / 10;
        MonsterList.instance.subBoss[0].rightArm.hp = MonsterList.instance.subBoss[0].rightArm.maxHp = 1 * GameManager.instance.healthRatio / 10;
        MonsterList.instance.subBoss[0].legs.hp = MonsterList.instance.subBoss[0].legs.maxHp =         1 * GameManager.instance.healthRatio / 10;

        GameManager.instance.agent.head.hp = GameManager.instance.agent.head.maxHp =                   8  * GameManager.instance.healthRatio / 10;
        GameManager.instance.agent.body.hp = GameManager.instance.agent.body.maxHp =                   20 * GameManager.instance.healthRatio / 10;
        GameManager.instance.agent.leftArm.hp = GameManager.instance.agent.leftArm.maxHp =             12 * GameManager.instance.healthRatio / 10;
        GameManager.instance.agent.rightArm.hp = GameManager.instance.agent.rightArm.maxHp =           12 * GameManager.instance.healthRatio / 10;
        GameManager.instance.agent.legs.hp = GameManager.instance.agent.legs.maxHp =                   15 * GameManager.instance.healthRatio / 10;
    }
    public static void SetArmorValues()
    {
        ItemList.instance.clothArmor[0].hp = ItemList.instance.clothArmor[0].maxHp =                   3 * GameManager.instance.armorRatio / 10;
        ItemList.instance.clothArmor[1].hp = ItemList.instance.clothArmor[1].maxHp =                   8 * GameManager.instance.armorRatio / 10;
        ItemList.instance.clothArmor[2].hp = ItemList.instance.clothArmor[2].maxHp =                   5 * GameManager.instance.armorRatio / 10;
        ItemList.instance.clothArmor[3].hp = ItemList.instance.clothArmor[3].maxHp =                   5 * GameManager.instance.armorRatio / 10;
        ItemList.instance.clothArmor[4].hp = ItemList.instance.clothArmor[4].maxHp =                   6 * GameManager.instance.armorRatio / 10;
                                                                                                       
        ItemList.instance.leatherArmor[0].hp = ItemList.instance.leatherArmor[0].maxHp =               6 * GameManager.instance.armorRatio / 10;
        ItemList.instance.leatherArmor[1].hp = ItemList.instance.leatherArmor[1].maxHp =               16 * GameManager.instance.armorRatio / 10;
        ItemList.instance.leatherArmor[2].hp = ItemList.instance.leatherArmor[2].maxHp =               10 * GameManager.instance.armorRatio / 10;
        ItemList.instance.leatherArmor[3].hp = ItemList.instance.leatherArmor[3].maxHp =               10 * GameManager.instance.armorRatio / 10;
        ItemList.instance.leatherArmor[4].hp = ItemList.instance.leatherArmor[4].maxHp =               12 * GameManager.instance.armorRatio / 10;
    }
    internal static int Damage(Agent attacker, Skill s)
    {
        Agent p = GameManager.instance.player;
        Arm rightArm = p.rightArm;
        Arm leftArm = p.leftArm;
        int damage = 0;
        int strength = (p.player.lastArmUsed == ArmUse.Right) ? (rightArm.strength) : (p.player.lastArmUsed == ArmUse.Left) ? leftArm.strength: (p.player.lastArmUsed == ArmUse.Both) ? rightArm.strength+leftArm.strength/2:0;
        if (s.skillName.Contains("Axe Cut"))         damage = Return.Int(4, 9)  + strength / 2;
        else if (s.skillName.Contains("Dagger Stab"))     damage = Return.Int(3, 8)  + strength / 3;
        else if (s.skillName.Contains("Punch"))           damage = Return.Int(2, 6)  + strength / 2;
        else if (s.skillName.Contains("Shield Bash"))     damage = Return.Int(3, 7)  + strength / 2;
        else if (s.skillName.Contains("Haymaker"))        damage = Return.Int(3, 7)  + strength / 2;
        else if (s.skillName.Contains("Uppercut"))        damage = Return.Int(3, 6)  + strength / 2;
        else if (s.skillName.Contains("Dagger Throw"))    damage = Return.Int(3, 8)  + strength / 3;
        else if (s.skillName.Contains("Bow Shoot"))       damage = Return.Int(3, 7)  + strength / 2;
        else if (s.skillName.Contains("Careful Shot"))    damage = Return.Int(4, 9)  + strength / 2;
        else if (s.skillName.Contains("Knockdown"))       damage = Return.Int(2, 5)  + strength / 2;
        else if (s.skillName.Contains("Double Shot"))     damage = Return.Int(3, 6)  + strength / 4;
        else if (s.skillName.Contains("Rapid Fire"))      damage = Return.Int(2, 5)  + strength / 4;
        else if (s.skillName.Contains("Sword Cleave"))    damage = Return.Int(2, 6)  + strength / 2;
        else if (s.skillName.Contains("Sword Stab"))      damage = Return.Int(3, 6)  + strength / 2;
        else if (s.skillName.Contains("Sword Cut"))       damage = Return.Int(3, 7)  + strength / 2;
        else if (s.skillName.Contains("Flame"))           damage = Return.Int(5, 10) + attacker.head.intelligence;
        return (damage + Return.SkillLevel(s) / 10) * GameManager.instance.damageRatio / 10;
    }
    internal static int Damage(int dam)
    {
        int damage = dam;
        return damage * GameManager.instance.damageRatio / 10;
    }
    internal static Body Target(Agent defender, Skill s)
    {
        if (s.skillName.Contains("Uppercut")) return Return.TargetBody(defender, 4, 3, 1, 1, 1);
        else if (s.skillName.Contains("Dagger Stab")|| s.skillName.Contains("Punch") || s.skillName.Contains("Sword Stab")) return Return.TargetBody(defender, 2, 3, 1, 1, 1);
        else if (s.skillName.Contains("Flame")) return Return.TargetBody(defender, 1, 1, 1, 1, 1);
        else if (s.skillName.Contains("Careful Shot")) return Return.TargetBody(defender, 4, 1, 1, 1, 1);
        return Return.TargetBody(defender, 1, 3, 2, 2, 2);
    }
}