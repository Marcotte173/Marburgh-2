using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Data", menuName = "Terrain", order = 1)]
public class Terrain : ScriptableObject
{
    public string terrainName;
    public List<string> description;
    public List<string> triggerString;
    public Sprite sprite;
}