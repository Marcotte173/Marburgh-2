using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FX : MonoBehaviour
{
    public static FX instance;
    public GameObject explosion;
    private void Awake()
    {
        instance = this;
    }
}
