﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FindTile : MonoBehaviour
{
    public static FindTile instance;
    private void Awake()
    {
        instance = this;
    }
    public Location Left(Location location)
    {
        foreach (Location l in Dungeon.instance.currentFloor.currentRoom.tileList)
        {
            if (l.x == location.x - 1 && l.y == location.y && l.cost != 99 && !GameManager.instance.occupied.Contains(l)) return l;
        }
        return null;
    }
    public Location Right(Location location)
    {
        foreach (Location l in Dungeon.instance.currentFloor.currentRoom.tileList)
        {
            if (l.x == location.x + 1 && l.y == location.y && l.cost != 99 && !GameManager.instance.occupied.Contains(l)) return l;
        }
        return null;
    }
    public Location Up(Location location)
    {
        foreach (Location l in Dungeon.instance.currentFloor.currentRoom.tileList)
        {
            if (l.x == location.x && l.y == location.y + 1 && l.cost != 99 && !GameManager.instance.occupied.Contains(l)) return l;
        }
        return null;
    }
    public Location Down(Location location)
    {
        foreach (Location l in Dungeon.instance.currentFloor.currentRoom.tileList)
        {
            if (l.x == location.x && l.y == location.y - 1 && l.cost != 99 && !GameManager.instance.occupied.Contains(l)) return l;
        }
        return null;
    }
}