﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;

public enum Status { Undamaged, SlightlyDamaged, Damaged, Destroyed }
public enum BodyType { Head, Torso, Arm, Leg };
public class Body : MonoBehaviour
{
    public string bodyName;
    public Agent source;
    public BodyType bodyType;
    public Status status;
    public int maxHp;
    public int hp;
    public ArmorScript armor;
    public List<Sprite> bodyStatus;
    public Sprite missing;
    public Image paperDoll;    

    private void Start()
    {
        source = GetComponentInParent<Agent>();
    }

    public void UpdateBody()
    {
        GetComponent<SpriteRenderer>().sprite = bodyStatus[(int)status];
        if (source.player != null) paperDoll.sprite =   GetComponent<SpriteRenderer>().sprite;
    }

    public void TakeDamage(int damage, bool report)
    {
        if (armor.type != ArmorType.None && armor.status != Status.Destroyed)
        {
            if (armor.hp > damage)
            {
                if(report)CombatLog.instance.UpdateLog(Return.AgentName(source,true,true) + " armor absorbs " + damage + " damage");
                armor.hp -= damage;
                damage = 0;
            }
            else
            {
                if (report) CombatLog.instance.UpdateLog(Return.AgentName(source, true, true) + " armor absorbs " + armor.hp + " damage");
                damage -= armor.hp;
                armor.hp = 0;
            }
        }
        if (report) CombatLog.instance.UpdateLog(Return.AgentName(source, true, false) + Return.Grammar(source, " take") +" "+ damage + " damage to the " +Return.BodyName(this));
        hp = (hp - damage <= 0) ? 0 : hp -= damage;
        //Update status
        status = Return.TheStatus(hp, maxHp);
        //Update damage taken if player got hit. Otherwise update damage given
        if (source.player != null) GameManager.instance.player.player.damageTaken += damage;
        else GameManager.instance.player.player.damageDone += damage;
        //If you bring a body part down to 0, diable it
        if (status == Status.Destroyed)
        {
            Destroyed();
        }
        //update sprites then update flavor
        GameManager.instance.UpdateSprites();
        if (source != GameManager.instance.player) source.Flavor();
    }

    public void ChangeHealth(int level,bool heal)
    {
        if (level > 4) level = 4;
        if (level < 0) level = 0;
        int newHealth = Return.HealthTreshhold(this, level);
        if (heal) CombatLog.instance.UpdateLog(Return.AgentName(source, true, true) + " " + Return.BodyName(this) + " begins to heal rapidly, as if by magic");
        else
        {
            CombatLog.instance.UpdateLog("Your " + Return.BodyName(this) + " withers, as if by spurned by dark magic");
            //If you bring a body part down to 0, diable it
            if (status == Status.Destroyed)
            {
                Destroyed();
            }
        }
        hp = newHealth;
        status = Return.TheStatus(hp, maxHp);  
        GameManager.instance.UpdateSprites();
        source.decisions.UpdateAvailableDecisions();
    }

    public virtual void Destroyed()
    {
        CombatLog.instance.UpdateLog(Return.AgentName(source, true, true) + " " + Return.BodyName(this) + " is disabled!");
        if (source.head == this || source.body == this) source.Death();
    }    
}