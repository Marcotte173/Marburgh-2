﻿using System;
using System.Linq;
using System.Collections.Generic;
public class Return
{
    public static Random rand = new Random();

    public static string playerColor = "#00ebffff";
    public static string enemyColor = "#127870ff";
    public static string skillColor = "#";
    public static string bodyColor = "#9C970E";
    public static string damageColor = "#";
    public static string disabledColor = "#";
    public static string fireColor = "D90606";

    public static int HealthTreshhold(Body b, int level)
    {
        if (level == 0) return b.maxHp;
        if (level == 1) return b.maxHp - 1;
        if (level == 2) return 2;
        return 0;
    }

    public static string AgentName(Agent a, bool capital, bool possessive)
    {
        string x = (capital) ? "You" : "you";
        if (possessive) x += "r";
        if (GameManager.instance.player == a) return $"<color={ playerColor}>{ x}</color>";
        string y = a.agentName;
        if (possessive) y += "'s";
        return $"<color={ enemyColor}>{ a.agentName}</color>";
    }
    public static string BodyName(Body b)
    {
        return $"<color={bodyColor}>{ b.bodyName}</color>";
    }
    public static string SkillName(Skill s)
    {
        return $"<color={skillColor}>{ s.actionName}</color>";
    }
    public static string ItemName(Item i)
    {
        if (i.weapon != null) return i.weapon.weaponName;
        if (i.armor != null) return i.armor.armorName;
        if (i.drop != null) return i.drop.dropName;
        return "Sold Out";
    }

    internal static string Grammar(Agent attacker, string v)
    {
        if (v == "is") return (attacker == GameManager.instance.player) ? "are" : "is";
        if (v == "miss") return (attacker == GameManager.instance.player) ? "miss" : "misses";
        if (v == "don't") return (attacker == GameManager.instance.player) ? "doesn't" : "don't";
        if (v == "parry") return (attacker == GameManager.instance.player) ? "parry" : "parries";
        return (attacker == GameManager.instance.player) ? v : v + "s";
    }

    public static int ItemValue(Item i)
    {
        if (i.weapon != null) return i.weapon.value;
        if (i.armor != null) return i.armor.value;
        if (i.drop != null) return i.drop.value;
        return 0;
    }

    public static Status TheStatus(int hp, int maxHp)
    {
        if (hp == maxHp) return Status.Undamaged;
        else if (hp == 0) return Status.Destroyed;
        else if (hp < 3) return Status.Damaged;
        else return Status.SlightlyDamaged;
    }

    public static bool Adjacent(Location a, Location b)
    {
        if (a.x == b.x + 1 && a.y == b.y) return true;
        if (a.x == b.x - 1 && a.y == b.y) return true;
        if (a.x == b.x + 1 && a.y == b.y + 1) return true;
        if (a.x == b.x - 1 && a.y == b.y + 1) return true;
        if (a.x == b.x + 1 && a.y == b.y - 1) return true;
        if (a.x == b.x - 1 && a.y == b.y - 1) return true;
        if (a.x == b.x && a.y == b.y + 1) return true;
        if (a.x == b.x && a.y == b.y - 1) return true;
        return false;
    }

    public static int Familiarity(Arm arm)
    {
        if (arm.weapon.availableActions[0].type == SkillType.Axe) return arm.source.axeFamiliarity;
        if (arm.weapon.availableActions[0].type == SkillType.Bow) return arm.source.bowFamiliarity;
        if (arm.weapon.availableActions[0].type == SkillType.Dagger) return arm.source.daggerFamiliarity;
        if (arm.weapon.availableActions[0].type == SkillType.Fist) return arm.source.fistFamiliarity;
        if (arm.weapon.availableActions[0].type == SkillType.GreatAxe) return arm.source.greatAxeFamiliarity;
        if (arm.weapon.availableActions[0].type == SkillType.GreatSword) return arm.source.greatSwordFamiliarity;
        if (arm.weapon.availableActions[0].type == SkillType.Shield) return arm.source.shieldFamiliarity;
        if (arm.weapon.availableActions[0].type == SkillType.Sword) return arm.source.swordFamiliarity;
        return 0;
    }
    internal static int BlockRequired(Weapon weapon)
    {
        foreach (Skill s in weapon.availableActions) if (s.actionName.Contains("Block")) return s.toHit;
        return 0;
    }

    internal static int ParryRequired(Weapon weapon)
    {
        foreach (Skill s in weapon.availableActions) if (s.actionName.Contains("Parry")) return s.toHit;
        return 0;
    }

    internal static int SkillLevel(Skill skill)
    {
        foreach (Skill s in GameManager.instance.player.player.skills)
        {
            if (s.skillName.Contains(skill.skillName))
            {
                return s.level;
            }
        }
        return 0;
    }

    public static int BlockLevel(Weapon weapon)
    {
        foreach (Skill skill in weapon.availableActions)
        {
            if (skill.actionName.Contains("Block"))
            {
                foreach (Skill s in GameManager.instance.player.player.skills)
                {
                    if (s.skillName.Contains(skill.skillName)) return s.level;
                }
            }
        }
        return 0;
    }
    public static int ParryLevel(Weapon weapon)
    {
        foreach (Skill skill in weapon.availableActions)
        {
            if (skill.actionName.Contains("Parry"))
            {
                foreach (Skill s in GameManager.instance.player.player.skills)
                {
                    if (s.skillName.Contains(skill.skillName)) return s.level;
                }
            }
        }
        return 0;
    }

    public static int Familiarity(Legs leg)
    {
        return leg.source.legFamiliarity;
    }

    public static string Item(BodyType body, ArmorType type)
    {
        if (body == BodyType.Head) return (type == ArmorType.Cloth) ? "Cloth Hat" : (type == ArmorType.Leather) ? "Leather Cap" : (type == ArmorType.Mail) ? "Chain Hood" : "Plate Helm";
        else if (body == BodyType.Torso) return (type == ArmorType.Cloth) ? "Cloth Tunic" : (type == ArmorType.Leather) ? "Leather Vest" : (type == ArmorType.Mail) ? "Chain Vest" : "Plate Mail";
        else if (body == BodyType.Arm) return (type == ArmorType.Cloth) ? "Cloth Sleeves" : (type == ArmorType.Leather) ? "Leather Vambraces" : (type == ArmorType.Mail) ? "Chain Sleeves" : "Plate Vambraces";
        else if (body == BodyType.Leg) return (type == ArmorType.Cloth) ? "Cloth pants" : (type == ArmorType.Leather) ? "Leather pants" : (type == ArmorType.Mail) ? "Chain pants" : "Plate Greaves";
        return null;
    }



    private static bool InRange(Location a, Location agent, int range)
    {
        List<Location> locations = new List<Location> { };
        locations.Add(a);
        for (int i = 0; i < range; i++)
        {
            foreach (Location b in locations.ToList()) foreach (Location n in b.neighbor) if (!locations.Contains(n)) locations.Add(n);
            foreach (Location b in locations) if (b == agent) return true;
        }
        return false;
    }

    public static Item NextEmptyInventorySlot()
    {
        for (int i = 0; i < 8; i++)
        {
            if (!GameManager.instance.player.player.inventory[i].NotEmpty())
            {
                return GameManager.instance.player.player.inventory[i];
            }
        }
        return null;
    }
    public static Location Location(int x, int y, List<Location> tileList)
    {
        foreach (Location loc in tileList) if (loc.x == x && loc.y == y) return loc;
        return null;
    }

    public static Body TargetBody(Agent a, int head, int body, int leftArm, int rightArm, int legs)
    {
        List<Body> potentialTarget = new List<Body> { };
        for (int i = 0; i < head; i++) potentialTarget.Add(a.head);
        for (int i = 0; i < body; i++) potentialTarget.Add(a.body);
        if (a.leftArm.status != Status.Destroyed) for (int i = 0; i < leftArm; i++) potentialTarget.Add(a.leftArm);
        if (a.rightArm.status != Status.Destroyed) for (int i = 0; i < rightArm; i++) potentialTarget.Add(a.rightArm);
        if (a.legs.status != Status.Destroyed) for (int i = 0; i < legs; i++) potentialTarget.Add(a.legs);
        return potentialTarget[Int(0, potentialTarget.Count)];
    }
    public static Body TargetBodyArmor(Agent a)
    {
        List<Body> potentialTarget = new List<Body> { };
        if (a.head.armor.type != ArmorType.None && a.head.armor.status != Status.Destroyed) potentialTarget.Add(a.head);
        if (a.body.armor.type != ArmorType.None && a.body.armor.status != Status.Destroyed) potentialTarget.Add(a.body);
        if (a.leftArm.armor.type != ArmorType.None && a.leftArm.armor.status != Status.Destroyed) potentialTarget.Add(a.leftArm);
        if (a.rightArm.armor.type != ArmorType.None && a.rightArm.armor.status != Status.Destroyed) potentialTarget.Add(a.rightArm);
        if (a.legs.armor.type != ArmorType.None && a.legs.armor.status != Status.Destroyed) potentialTarget.Add(a.legs);
        if (potentialTarget.Count > 0) return potentialTarget[Int(0, potentialTarget.Count)];
        return null;
    }

    public static int Int(int x, int y) => rand.Next(x, y);

    public static bool Check100(int x) => rand.Next(0, 101) <= x;

    internal static void SortPriority(List<Skill> list)
    {
        Skill temp;
        for (int j = 0; j <= list.Count - 2; j++)
        {
            for (int i = 0; i <= list.Count - 2; i++)
            {
                if (list[i].priority < list[i + 1].priority)
                {
                    temp = list[i + 1];
                    list[i + 1] = list[i];
                    list[i] = temp;
                }
            }
        }
    }

    internal static void SortNeed(List<Body> list)
    {
        Body temp;
        for (int j = 0; j <= list.Count - 2; j++)
        {
            for (int i = 0; i <= list.Count - 2; i++)
            {
                if ((int)list[i].status < (int)list[i + 1].status)
                {
                    temp = list[i + 1];
                    list[i + 1] = list[i];
                    list[i] = temp;
                }
            }
        }
    }
    internal static void SortHave(List<Body> list)
    {
        Body temp;
        for (int j = 0; j <= list.Count - 2; j++)
        {
            for (int i = 0; i <= list.Count - 2; i++)
            {
                if ((int)list[i].status > (int)list[i + 1].status)
                {
                    temp = list[i + 1];
                    list[i + 1] = list[i];
                    list[i] = temp;
                }
            }
        }
    }


    internal static List<Agent> TargetsInRange(Agent agent, int range)
    {
        List<Agent> agents = new List<Agent> { };
        Agent p = GameManager.instance.player;
        foreach (Agent a in Dungeon.instance.currentFloor.currentRoom.agentList)
        {
            if ((agent == p && a != p) || (a == p && agent != p)) if (InRange(a.location, agent.location, range)) agents.Add(a);
        }
        return agents;
    }

    internal static bool CanAfford(int v) => GameManager.instance.player.player.gold >= v;

    internal static bool ConditionCheck(Skill s, Agent attacker)
    {
        List<Agent> targets = TargetsInRange(attacker, s.range);
        if (s.type == SkillType.Fist && attacker.rightArm.weapon.handed == Handed.Two) return false;
        if (s.actionName == "Rend Armor")
        {
            foreach (Agent target in targets)
            {
                if (TargetBodyArmor(target) != null) return true;
            }
            return false;
        }
        if (s.actionName == "Break Shield")
        {
            foreach (Agent target in targets)
            {
                if (target.rightArm.weapon.availableActions[0].type == SkillType.Shield || target.leftArm.weapon.availableActions[0].type == SkillType.Shield) return true;
            }
            return false;
        }
        if (s.actionName == "Double Shot")
        {
            int amount = 0;
            foreach (Agent target in targets)
            {
                if (target != GameManager.instance.player) amount++;                
            }            
            return (amount>1)?true:false;
        }
        return true;
    }

    internal static Location OppositeTile(Agent defender, Agent attacker)
    {
        
        Location d = defender.location;
        Location a = attacker.location;
        int x = a.x - d.x;
        int y = a.y - d.y;
        foreach (Location l in Dungeon.instance.currentFloor.currentRoom.tileList) if (l.x == d.x - x && l.y == d.y - y) return l;
        return null;
    }
}