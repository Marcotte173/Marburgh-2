using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum RoomType {Large, Small, Library, Kitchen, Lab, Latrine, Prison, Boss,Healing,Shop };
public class Room : MonoBehaviour
{
    public int x;
    public int y;
    public RoomType type;
    public List<Location> possibleEnemyStartingLocation;
    public Floor floor;
    public List<Location> tileList;
    public List<Agent> agentList;
    public List<Agent> enemyList;
    public bool stairDown;
    public List<Item> items;
    public List<Item> terrain;
    public List<Item> staticObjects;
    public bool smaller;

    public Location[] entrances = new Location[] { null, null, null, null };
    public Room[] neighbors = new Room[] { null, null, null, null };
    public Room[] connectedRooms = new Room[] { null, null, null, null };

    public void CreateBasicRoom(int entrance)
    {
        for (int y = 0; y < 9; y++)
        {
            for (int x = 0; x < 9; x++)
            {
                Location l = Instantiate(GameManager.instance.location, transform);
                l.x = x;
                l.y = y;
                tileList.Add(l);
                l.transform.position = new Vector2(l.x, l.y);
                l.name = $"{l.x} , {l.y}";
                if (x == 0 || x == 8 || y == 0 || y == 8) Wall(l);
                else Floor(l);
            }            
        }
        foreach (Location l in tileList)
        {
            foreach (Location loc in tileList)
            {
                if (loc.x == l.x + 1 && loc.y == l.y) if (!l.neighbor.Contains(loc)) l.neighbor.Add(loc);
                if (loc.x == l.x - 1 && loc.y == l.y) if (!l.neighbor.Contains(loc)) l.neighbor.Add(loc);
                if (loc.x == l.x && loc.y == l.y + 1) if (!l.neighbor.Contains(loc)) l.neighbor.Add(loc);
                if (loc.x == l.x && loc.y == l.y - 1) if (!l.neighbor.Contains(loc)) l.neighbor.Add(loc);

                if (loc.x == l.x + 1 && loc.y == l.y + 1) if (!l.neighbor.Contains(loc)) l.neighbor.Add(loc);
                if (loc.x == l.x - 1 && loc.y == l.y + 1) if (!l.neighbor.Contains(loc)) l.neighbor.Add(loc);
                if (loc.x == l.x + 1 && loc.y == l.y - 1) if (!l.neighbor.Contains(loc)) l.neighbor.Add(loc);
                if (loc.x == l.x - 1 && loc.y == l.y - 1) if (!l.neighbor.Contains(loc)) l.neighbor.Add(loc);

            }
            if (l.x > 2 && l.x < 6 && l.y > 2 && l.y < 6) possibleEnemyStartingLocation.Add(l);
        }        
        if (entrance != 0) BuildEntrance(entrance);
        Dungeon.instance.currentFloor.builtRooms.Add(this);
    }


    public void Spawn(int x, int y, Weapon w, Armor a, Drop d, Terrain t)
    {
        Item g = Instantiate(GameManager.instance.item, transform);
        if (t == null) items.Add(g);
        else terrain.Add(g);
        g.transform.position = new Vector2(x, y);
        g.location = Return.Location(x, y, tileList);
        if (w != null)
        {
            Weapon n = Instantiate(w, transform);
            g.weapon = n;
            g.flavor = n.description;
        }
        else if (a != null)
        {
            Armor n = Instantiate(a, transform);
            g.armor = n;
            g.flavor = n.description;
        }
        else if (d != null)
        {
            Drop n = Instantiate(d, transform);
            g.drop = n;
            if (d.type == DropType.Gold)
            {
                g.value = Return.Int(12, 65);
                g.flavor.Add($"There are {g.value} gold pieces on the ground. You should pick them up");
            }
            else g.flavor.Add(d.flavor);
        }
        else if (t != null)
        {
            Terrain n = Instantiate(t, transform);
            g.terrain = n;
            g.location.cost = 99;
            if (t == ItemList.instance.fountain) g.gameObject.AddComponent<Fountain>();
        }
        g.ChangeSprite();
    }
    public void BuildEntrance(int entrance)
    {
        if (entrance == 13)
        {
            Location l = Return.Location(3, 3, tileList);
            l.GetComponent<SpriteRenderer>().sprite = GameManager.instance.upStair;
            l.cost = 101;
        }
        else
        {
            if (entrance == 1) BuildNorthDoor(3, 8);
            else if (entrance == 2) BuildNorthDoor(6, 8);
            else if (entrance == 3) BuildEastDoor(8, 6);
            else if (entrance == 4) BuildEastDoor(8, 3);
            else if (entrance == 5) BuildSouthDoor(6, 0);
            else if (entrance == 6) BuildSouthDoor(3, 0);
            else if (entrance == 7) BuildWestDoor(0, 3);
            else if (entrance == 8) BuildWestDoor(0, 6);
            else if (entrance == 9) BuildNorthDoor(4, 8);
            else if (entrance == 10) BuildEastDoor(8, 4);
            else if (entrance == 11) BuildSouthDoor(4, 0);
            else if (entrance == 12) BuildWestDoor(0, 4);
        }
    }

    public void Populate()
    {
        if (floor.builtRooms[0] == this)
        {
            MakeTheRoomSmaller();
        }
        else if (floor.builtRooms[floor.builtRooms.Count - 1] == this)
        {
            type = RoomType.Boss;
            SummonBoss();
            GameManager.instance.FindLocation();            
        }
        else if (floor.builtRooms[floor.healingRoll] == this)
        {
            type = RoomType.Healing;
            MakeTheRoomSmaller();
            Spawn(4, 4, null, null, null, ItemList.instance.fountain);
        }
        else if (floor.builtRooms[floor.shopRoll] == this)
        {
            type = RoomType.Shop;
            MakeTheRoomSmaller();
            Spawn(4, 4, null, null, null, ItemList.instance.shopKeeper);
            GameManager.instance.player.player.ShopStock();
        }
        else if (floor.builtRooms[floor.kitchenRoll] == this)
        {
            type = RoomType.Kitchen;
            MakeTheRoomSmaller();
            SummonSubBoss();
            foreach (Location l in tileList)
            {
                if (l.cost == 1)
                {
                    l.description = "The blood stained ground could really use a good clean\nGet Scrubbin'";
                    l.GetComponent<SpriteRenderer>().sprite = Kitchen.instance.floor[Return.Int(0, Kitchen.instance.floor.Count)];
                }
                if ((l.x == 3 && l.y == 7) && l.cost != 100)
                {
                    Kitchen.instance.tableWithMeat.sprite = Kitchen.instance.tables[Return.Int(0, Kitchen.instance.tables.Count)];
                    Spawn(3, 6, Kitchen.instance.tableWithMeat, false);
                }
                if ((l.x == 4 && l.y == 7) && l.cost != 100)
                {
                    Kitchen.instance.tableWithMeat.sprite = Kitchen.instance.tables[Return.Int(0, Kitchen.instance.tables.Count)];
                    Spawn(4, 6, Kitchen.instance.tableWithMeat, false);
                }
                if ((l.x == 5 && l.y == 7) && l.cost != 100)
                {
                    Kitchen.instance.tableWithMeat.sprite = Kitchen.instance.tables[Return.Int(0, Kitchen.instance.tables.Count)];
                    Spawn(5, 6, Kitchen.instance.tableWithMeat, false);
                }
            }
            Kitchen.instance.corpse.sprite = Kitchen.instance.corpses[Return.Int(0, Kitchen.instance.corpses.Count)];
            Spawn(3, 4, Kitchen.instance.corpse, true);
            Kitchen.instance.corpse.sprite = Kitchen.instance.corpses[Return.Int(0, Kitchen.instance.corpses.Count)];
            Spawn(4, 3, Kitchen.instance.corpse, true);
        }
        else if (floor.builtRooms[floor.libraryRoll] == this)
        {
            type = RoomType.Library;
            MakeTheRoomSmaller();
            foreach (Location l in tileList)
            {
                if (l.cost == 1)
                {
                    l.GetComponent<SpriteRenderer>().sprite = Library.instance.libraryFloor;
                    l.description = "You are looking a plush, purple carpet.\nVery elegant.";
                }
                if (l.x == 8 || l.x == 0 || l.y == 8 || l.y == 0) l.GetComponent<SpriteRenderer>().sprite = ItemList.instance.none.sprite;
                else if ((l.x == 7 || l.x == 1 || l.y == 7 || l.y == 1) && l.cost != 100)
                {
                    l.cost = 99;
                    l.description = "You are looking at the walls. Why are you looking at the walls?";
                    l.GetComponent<SpriteRenderer>().sprite = Library.instance.libraryWall;
                    if (l.x == 1 && l.y == 2)
                    {
                        Library.instance.bookshelf.sprite = Library.instance.booksWest[0];
                        Spawn(2, 2, Library.instance.bookshelf, true);
                    }
                    if (l.x == 1 && l.y == 3)
                    {
                        Library.instance.bookshelf.sprite = Library.instance.booksWest[0];
                        Spawn(2, 3, Library.instance.bookshelf, true);
                    }
                    if (l.x == 1 && l.y == 4)
                    {
                        Library.instance.bookshelf.sprite = Library.instance.booksWest[0];
                        Spawn(2, 4, Library.instance.bookshelf, true);
                    }
                    if (l.x == 1 && l.y == 5)
                    {
                        Library.instance.bookshelf.sprite = Library.instance.booksWest[0];
                        Spawn(2, 5, Library.instance.bookshelf, true);
                    }
                    if (l.x == 1 && l.y == 6)
                    {
                        Library.instance.bookshelf.sprite = Library.instance.booksWest[0];
                        Spawn(2, 6, Library.instance.bookshelf, true);
                    }
                    if (l.x == 7 && l.y == 2)
                    {
                        Library.instance.bookshelf.sprite = Library.instance.booksEast[0];
                        Spawn(6, 2, Library.instance.bookshelf, true);
                    }
                    if (l.x == 7 && l.y == 3)
                    {
                        Library.instance.bookshelf.sprite = Library.instance.booksEast[0];
                        Spawn(6, 3, Library.instance.bookshelf, true);
                    }
                    if (l.x == 7 && l.y == 4)
                    {
                        Library.instance.bookshelf.sprite = Library.instance.booksEast[0];
                        Spawn(6, 4, Library.instance.bookshelf, true);
                    }
                    if (l.x == 7 && l.y == 5)
                    {
                        Library.instance.bookshelf.sprite = Library.instance.booksEast[0];
                        Spawn(6, 5, Library.instance.bookshelf, true);
                    }
                    if (l.x == 7 && l.y == 6)
                    {
                        Library.instance.bookshelf.sprite = Library.instance.booksEast[0];
                        Spawn(6, 6, Library.instance.bookshelf, true);
                    }
                    if (l.x == 2 && l.y == 7)
                    {
                        Library.instance.bookshelf.sprite = Library.instance.booksNorth[0];
                        Spawn(2, 7, Library.instance.bookshelf, false);
                    }
                    if (l.x == 3 && l.y == 7)
                    {
                        Library.instance.bookshelf.sprite = Library.instance.booksNorth[1];
                        Spawn(3, 7, Library.instance.bookshelf, false);
                    }
                    if (l.x == 4 && l.y == 7)
                    {
                        Library.instance.bookshelf.sprite = Library.instance.booksNorth[0];
                        Spawn(4, 7, Library.instance.bookshelf, false);
                    }
                    if (l.x == 5 && l.y == 7)
                    {
                        Library.instance.bookshelf.sprite = Library.instance.booksNorth[1];
                        Spawn(5, 7, Library.instance.bookshelf, false);
                    }
                    if (l.x == 6 && l.y == 7)
                    {
                        Library.instance.bookshelf.sprite = Library.instance.booksNorth[0];
                        Spawn(6, 7, Library.instance.bookshelf, false);
                    }
                    if (l.x == 3 && l.y == 1)
                    {
                        Library.instance.bookshelf.sprite = Library.instance.booksSouth[0];
                        Spawn(3, 2, Library.instance.bookshelf, true);
                    }
                    if (l.x == 4 && l.y == 1)
                    {
                        Library.instance.bookshelf.sprite = Library.instance.booksSouth[0];
                        Spawn(4, 2, Library.instance.bookshelf, true);
                    }
                    if (l.x == 5 && l.y == 1)
                    {
                        Library.instance.bookshelf.sprite = Library.instance.booksSouth[0];
                        Spawn(5, 2, Library.instance.bookshelf, true);
                    }
                }
            }
            Spawn(4, 4, null, null, ItemList.instance.bookOfFlame, null);

        }
        else
        {            
            type = RoomType.Small;
            MakeTheRoomSmaller();
            SummonEnemy(2);
        }
    }

    private void Spawn(int x, int y, Static item,bool walkable)
    {
        Item g = Instantiate(GameManager.instance.item, transform);
        staticObjects.Add(g);
        g.flavor = item.description;
        g.transform.position = new Vector2(x, y);
        g.location = Return.Location(x, y, tileList);
        Static n = Instantiate(item, transform);
        g.staticObject = n;
        g.location.cost = (walkable)?1:99;
        g.ChangeSprite();
    }

    public void MakeTheRoomSmaller()
    {
        ConvertEntrance(1);
        foreach (Location l in tileList)
        {
            if (l.x == 8 || l.x == 0 || l.y == 8 || l.y == 0) l.GetComponent<SpriteRenderer>().sprite = ItemList.instance.none.sprite;
            else if ((l.x == 7 || l.x == 1 || l.y == 7 || l.y == 1) && l.cost != 100)
            {
                l.cost = 99;
                l.description = "You are looking at the walls. Why are you looking at the walls?";
                l.GetComponent<SpriteRenderer>().sprite = GameManager.instance.wall;
            }
        }
    }

    private void ConvertEntrance(int x)
    {
        if (x == 1)
        {
            if (entrances[0] != null)
            {
                if (Entrance1(entrances[0])) BuildNorthDoor(3, 7);
                if (Entrance2(entrances[0])) BuildNorthDoor(6, 7);
                if (Entrance9(entrances[0])) BuildNorthDoor(4, 7);
            }
            if (entrances[2] != null)
            {
                if (Entrance3(entrances[2])) BuildEastDoor(7, 6);
                if (Entrance4(entrances[2])) BuildEastDoor(7, 3);
                if (Entrance10(entrances[2])) BuildEastDoor(7, 4);
            }
            if (entrances[1] != null)
            {
                if (Entrance5(entrances[1])) BuildSouthDoor(6, 1);
                if (Entrance6(entrances[1])) BuildSouthDoor(3, 1);
                if (Entrance11(entrances[1])) BuildSouthDoor(4, 1);
            }
            if (entrances[3] != null)
            {
                if (Entrance7(entrances[3])) BuildWestDoor(1, 3);
                if (Entrance8(entrances[3])) BuildWestDoor(1, 6);
                if (Entrance12(entrances[3])) BuildWestDoor(1, 4);
            }
        }
    }

    private void SummonSubBoss()
    {
        Agent f = Instantiate(MonsterList.instance.subBoss[Dungeon.instance.currentFloor.floorNumber - 1], transform);
        enemyList.Add(f);
        f.decisions.guarding = false;
        f.nameText.text = f.agentName;
        GetStartingLocation(f);
    }


    private void SummonBoss()
    {
        Agent f = Instantiate(MonsterList.instance.boss[Dungeon.instance.currentFloor.floorNumber - 1], transform);
        enemyList.Add(f);
        f.nameText.text = f.agentName;
        f.decisions.guarding = false;
        GetStartingLocation(f);
    }

    private void SummonEnemy(int x)
    {
        List<string> names = Names.instance.list;
        for (int i = 0; i < Return.Int(1, (x + 1)); i++)
        {
            Agent f = Instantiate(MonsterList.instance.human1[Return.Int(0, MonsterList.instance.human1.Count)], transform);
            enemyList.Add(f);
            int nameRoll = Return.Int(0, names.Count);
            f.agentName = names[nameRoll] + " the " + f.agentName;
            names.RemoveAt(nameRoll);
            f.nameText.text = f.agentName ;
            f.Flavor();   
            GetStartingLocation(f);
            f.decisions.guarding = false;
        }
    }
    public  void Door(Location l)
    {
        l.GetComponent<SpriteRenderer>().sprite = GameManager.instance.door;
        l.cost = 100;
        l.locked = false;
        l.description = "You are looking at a door. I wonder where it leads";
    }
    public  void LockedDoor(Location l)
    {
        l.GetComponent<SpriteRenderer>().sprite = GameManager.instance.lockedDoor;
        l.cost = 100;
        l.locked = true;
        l.description = "You see a door with a heavy lock. You probably need a key";
    }

    private void Floor(Location l)
    {
        l.cost = 1;
        l.description = "You see a bare floor";
        l.GetComponent<SpriteRenderer>().sprite = GameManager.instance.floor[Return.Int(0, 2)];
    }

    private void Wall(Location l)
    {
        l.cost = 99;
        l.description = "You are looking at the walls. Why are you looking at the walls?";
        l.GetComponent<SpriteRenderer>().sprite = GameManager.instance.wall;
    }
    public void BuildNorthDoor(int x, int y)
    {
        Location l = Return.Location(x, y, tileList);
        entrances[0] = l;
        Door(l);
    }

    public void BuildSouthDoor(int x, int y)
    {
        Location l = Return.Location(x, y, tileList);
        entrances[1] = l;
        Door(l);
    }
    public void BuildEastDoor(int x, int y)
    {
        Location l = Return.Location(x, y, tileList);
        entrances[2] = l;
        Door(l);
    }

    public void BuildWestDoor(int x, int y)
    {
        Location l = Return.Location(x, y, tileList);
        entrances[3] = l;
        Door(l);
    }
    internal void Enter()
    {
        foreach (GameObject g in Action.instance.projectiles) GameManager.instance.TurnOff(g);        
        agentList.Clear();
        agentList.Add(GameManager.instance.player);
        foreach (Agent a in enemyList)
        {
            if (!a.dead)
            {
                agentList.Add(a);
                a.transform.position = new Vector2(a.GetComponent<Enemy>().startingLocation.x, a.GetComponent<Enemy>().startingLocation.y);
            }
        }
        GameManager.instance.FindLocation();
        GameManager.instance.UpdateSprites();
        CombatLog.instance.UpdateLog("");
        GameManager.instance.player.decisions.UpdateAvailableDecisions();
    }

    private void GetStartingLocation(Agent f)
    {
        int x = Return.Int(0, possibleEnemyStartingLocation.Count);
        f.GetComponent<Enemy>().startingLocation = possibleEnemyStartingLocation[x];
        possibleEnemyStartingLocation.RemoveAt(x);
        GameManager.instance.FindLocation();
    }
    
    private bool Entrance1(Location l) => l.x == 3 && l.y == 8;
    private bool Entrance2(Location l) => l.x == 6 && l.y == 8;
    private bool Entrance3(Location l) => l.x == 8 && l.y == 6;
    private bool Entrance4(Location l) => l.x == 8 && l.y == 3;
    private bool Entrance5(Location l) => l.x == 6 && l.y == 0;
    private bool Entrance6(Location l) => l.x == 3 && l.y == 0;
    private bool Entrance7(Location l) => l.x == 0 && l.y == 3;
    private bool Entrance8(Location l) => l.x == 0 && l.y == 6;
    private bool Entrance9(Location l) => l.x == 4 && l.y == 8;
    private bool Entrance10(Location l) => l.x == 8 && l.y == 4;
    private bool Entrance11(Location l) => l.x == 4 && l.y == 0;
    private bool Entrance12(Location l) => l.x == 0 && l.y == 4;
}