﻿using System;
using System.Collections;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices.WindowsRuntime;
using UnityEngine;
using UnityEngine.UI;

public class Legs : Body
{
    public Dropdown dropDown;
    public Button button;
    public Text text;
    public int movement;
    public List<Skill> availableActions;
    public List<Location> path;
    public List<Location> open = new List<Location> { };
    public List<Location> closed = new List<Location> { };
    public List<Location> unwalkable = new List<Location> { };

    public void MoveToTile(Location tile)
    {
        Agent p = GameManager.instance.player;
        if (tile != null)
        { 
            if(tile.locked && source == p)
            {
                bool unlock = false;
                for (int i = 0; i < 8; i++)
                {
                    if (p.player.inventory[i].drop != null && p.player.inventory[i].drop.dropName == MonsterList.instance.bossKeys[Dungeon.instance.currentFloor.floorNumber - 1].dropName)
                    {
                        unlock = true;
                        GameManager.instance.NullifyItem(p.player.inventory[i]);
                        break;
                    }
                }
                if (unlock)
                {
                    Dungeon.instance.currentFloor.currentRoom.Door(tile);
                    CombatLog.instance.UpdateLog("With a click, the door opens!");
                }
                else
                {
                    CombatLog.instance.UpdateLog("The door is locked, Find the key");
                }
            }
            else
            {
                source.transform.position = new Vector2(tile.x, tile.y);
                if (source = GameManager.instance.player)
                {
                    source.StopCasting();
                    CombatLog.instance.Clean();
                    GameManager.instance.FindLocation();
                    foreach (Item i in Dungeon.instance.currentFloor.currentRoom.terrain)
                    {
                        if (Return.Adjacent(source.location, i.location))
                        {
                            i.player = true;
                            if (CombatLog.instance.text.Count == 0 || CombatLog.instance.text[CombatLog.instance.text.Count - 1] != i.terrain.description[i.terrain.description.Count - 1])
                            {
                                foreach (String s in i.terrain.description)
                                    CombatLog.instance.UpdateLog(s);
                            }
                        }
                        else i.player = false;
                    }
                    foreach (Item i in Dungeon.instance.currentFloor.currentRoom.items)
                    {
                        if (Return.Adjacent(source.location, i.location))
                        {
                            foreach (string s in i.flavor) CombatLog.instance.UpdateLog(s);
                        }
                    }
                    if (!source.moved)
                    {
                       GameManager.instance.EndTurn();
                    }
                }
            }                                 
        }
    }

    internal void MoveTowards(Location end)
    {
        Location start = source.location;
        path.Clear();
        open.Clear();
        closed.Clear();
        unwalkable.Clear();
        foreach (Agent a in Dungeon.instance.currentFloor.currentRoom.agentList)
        {
            if (a != source.target) unwalkable.Add(a.location);
        }
        Location current = start;
        open.Add(current);
        while (!closed.Contains(end))
        {
            foreach (Location neighbor in current.neighbor)
            {
                //Calculate each neighbor's f value
                if (neighbor.x == current.x + 1 && (neighbor.y == current.y + 1 || neighbor.y == current.y - 1)) neighbor.g = 300;
                else if (neighbor.x == current.x - 1 && (neighbor.y == current.y + 1 || neighbor.y == current.y - 1)) neighbor.g = 300;
                else neighbor.g = 1;
                neighbor.h = Vector3.Distance(neighbor.transform.position, end.transform.position);
                neighbor.f = (neighbor.g + neighbor.h);

                //Adding neighbor to the open list
                foreach (Location t in open.ToList())
                {
                    if (neighbor == t && neighbor.f < t.f)
                    {
                        t.f = neighbor.f;
                        neighbor.parent = current;
                    }
                    else if (!open.Contains(neighbor) && (!closed.Contains(neighbor)) && !unwalkable.Contains(neighbor))
                    {
                        neighbor.parent = current;
                        open.Add(neighbor);
                    }
                }
            }
            open.Remove(current);
            closed.Add(current);
            if (open.Count > 0)
            {
                current = open[0];
                for (int i = 1; i < open.Count; i++) { if (open[i].f < current.f) current = open[i]; }
                if (current == end) break;
            }
            else break;
        }
        while (current.parent != start)
        {
            path.Add(current.parent);
            current = current.parent;
        }
        if (path.Count > 0)
        {
            path.Reverse();
            Location tile = path[0];
            source.transform.position = new Vector2(tile.x, tile.y);
        }        
    }

    public void Movement(int x)
    {
        movement += x;
        if(x>0) CombatLog.instance.UpdateLog("You feel faster");
        else CombatLog.instance.UpdateLog("Your legs feel slow and clumsy");
    }
}
