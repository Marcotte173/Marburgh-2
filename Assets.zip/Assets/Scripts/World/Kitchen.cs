using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Kitchen : MonoBehaviour
{
    public static Kitchen instance;
    public List<Sprite> floor;
    public List<Sprite> tables;
    public List<Sprite> corpses;
    public Static tableWithMeat;
    public Static corpse; 
    void Awake()
    {
        instance = this;   
    }
}