using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum ArmorSlot { Head,Body,LeftArm,RightArm,Legs }
[CreateAssetMenu(fileName = "Data", menuName = "Armor", order = 1)]
public class Armor : ScriptableObject
{
    public ArmorType type;
    public int value;
    public string armorName;
    public int maxHp;
    public int hp;
    public Sprite sprite;
    public Sprite inventorySprite;
    public List<string> description;
    public bool shop;
    public ArmorSlot slot;
}