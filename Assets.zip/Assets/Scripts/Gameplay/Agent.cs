﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Agent : MonoBehaviour
{
    public Player player;
    public Enemy enemy;
    public Decisions decisions;
    public string whoHitMeLast;
    public List<string> flavor;
    public string agentName;
    public Arm rightArm;
    public Arm leftArm;
    public Legs legs;
    public Body body;
    public Head head;
    public bool dead;
    public Location location;
    public bool moved;
    public Agent target;
    public Text nameText;
    public int onFire;
    public int fireDamage;
    public int swordFamiliarity;
    public int greatAxeFamiliarity;
    public int greatSwordFamiliarity;
    public int fistFamiliarity;
    public int shieldFamiliarity;
    public int axeFamiliarity;
    public int bowFamiliarity;
    public int daggerFamiliarity;
    public int legFamiliarity;
    public bool casting;
    public Skill castSkill;
    public Arm castArm;
    public Weapon castWeapon;
    public Agent castDefender;
    public GameObject castObject;
    public Button castButton;
    public int knockedDown;
    public int resilience;
    public SpellCasting spell;
    public Location oppositeLocation;

    private void Awake()
    {
        decisions = GetComponent<Decisions>();
        if (GetComponent<Player>())
        {
            player = GetComponent<Player>();
            player.source = this;
        }
        else
        {
            enemy = GetComponent<Enemy>();
            enemy.source = this;
        }
    }
    public void EquipWeapons(Weapon leftWeapon, Weapon rightWeapon, Weapon oldWeaponLeft, Weapon oldWeaponRight)
    {
        //Find out if either hand has a new weapon
        Weapon newWeapon = null;
        if (leftWeapon != oldWeaponLeft) newWeapon = leftWeapon;
        if (rightWeapon != oldWeaponRight) newWeapon = rightWeapon;
        //Equip the current weapon
        leftArm.Equip(leftWeapon);
        rightArm.Equip(rightWeapon);
        //If either of them are new, Look out for 2 handed wackiness. Added no right hand two hander with left hand fist to stop stupid bug.
        if (newWeapon != null)
        {
            if (newWeapon == leftWeapon)
            {
                if(rightWeapon.handed == Handed.Two)
                {
                    for (int i = 0; i < 8; i++)
                    {
                        if (GameManager.instance.Empty(player.inventory[i]))
                        {
                            player.inventory[i].weapon = oldWeaponRight;
                            rightArm.Equip(ItemList.instance.rightFist);
                            player.inventory[14].weapon = ItemList.instance.rightFist;
                            break;
                        }
                    }
                }
            }
            if (newWeapon == rightWeapon )
            {
                if (rightWeapon.handed == Handed.Two)
                {
                    if (oldWeaponLeft.weaponName != "Fist")
                    {
                        for (int i = 0; i < 8; i++)
                        {
                            if (GameManager.instance.Empty(player.inventory[i]))
                            {
                                player.inventory[i].weapon = oldWeaponLeft;
                                leftArm.Equip(ItemList.instance.leftFist);
                                player.inventory[13].weapon = ItemList.instance.leftFist;
                                break;
                            }
                        }
                    }
                }
            }
        }
        decisions.UpdateAvailableDecisions();
    }
    public void Cast()
    {
        Action.instance.Weapon(this, castArm, castDefender, castWeapon, castSkill);
        GameManager.instance.EndTurn();
    }
    public void StopCasting()
    {
        casting = false;
        if (spell != null) spell.spell.Clear();
        if (this == GameManager.instance.player)
        {
            GameManager.instance.TurnOff(castObject);
            GameManager.instance.TurnOff(spell.castObject);
        }     
        GetComponent<Decisions>().UpdateAvailableDecisions();
    }
    public void Death()
    {
        dead = true;
        if (player!= null)
        {
            player.Death();
        }
        else
        {            
            GameManager.instance.player.player.monstersSlain++;
            Dungeon.instance.currentFloor.currentRoom.agentList.Remove(this);
            CombatLog.instance.UpdateLog(agentName + " has been killed!");
            if (MonsterList.instance.boss[0].agentName == this.agentName)
            {
                Debug.Log("Woo!");
                GameManager.instance.player.player.Win();
            }
            if (Return.Int(0,100)<GetComponent<Enemy>().dropChance) GetComponent<Enemy>().DropGear(location.x, location.y);
            Destroy(gameObject);
        }
    }

    public void NewGameButton()
    {
        GameManager.instance.NewGame();
    }

    public void Flavor()
    {
        flavor.Clear();
        flavor.Add($"You are looking at a {agentName}");
        bool a = (rightArm.weapon.weaponName != "Fist"&& rightArm.weapon.weaponName != "Two Hand") ? true : false;
        bool b = (leftArm.weapon.weaponName != "Fist" && leftArm.weapon.weaponName != "Two Hand") ? true : false;
        string c = (a && b) ? $"He is wielding a {rightArm.weapon.weaponName} and a {leftArm.weapon.weaponName}" : (a) ? $"He is wielding a {rightArm.weapon.weaponName}" : (b) ? $"He is wielding a {leftArm.weapon.weaponName}" : "He does not have any weapons";
        flavor.Add(c);
        bool undamaged = true;
        if(legs.status == Status.Damaged)
        {
            undamaged = false;
            flavor.Add("He is walking with a limp");
        }
        else if (legs.status == Status.Destroyed)
        {
            undamaged = false;
            flavor.Add("He can barely walk");
        }
        if (rightArm.status == Status.Damaged)
        {
            undamaged = false;
            flavor.Add("He is favoring his right arm");
        }
        else if (rightArm.status == Status.Destroyed)
        {
            undamaged = false;
            flavor.Add("His right arm hangs useless");
        }
        if (leftArm.status == Status.Damaged)
        {
            undamaged = false;
            flavor.Add("He is favoring his left arm");
        }
        else if (leftArm.status == Status.Destroyed)
        {
            undamaged = false;
            flavor.Add("His left arm hangs useless");
        }
        if(body.status == Status.Damaged)
        {
            undamaged = false;
            flavor.Add("He winces when he breaths, as if he has a broken rib");
        }
        if(head.status == Status.Damaged)
        {
            undamaged = false;
            flavor.Add("He has trouble seeing out of his swollen eye");
        }
        if(undamaged)flavor.Add("He looks ready to fight");
    }


    internal void RaiseFamiliarity(Skill skill, Weapon w, int raise)
    {
        bool upgrade = false;
        string log= "";
        if (skill.type == SkillType.Axe)
        {
            axeFamiliarity+= raise;
            foreach (Skill s in w.availableActions)
            {
                if (s.familiarityRequired == axeFamiliarity)
                {
                    upgrade = true;
                    log = $"You can now use {s.actionName}";
                }
            }
        }
        else if (skill.type == SkillType.Bow) 
        {
            bowFamiliarity += raise;
            foreach (Skill s in w.availableActions)
            {
                if (s.familiarityRequired == bowFamiliarity)
                {
                    upgrade = true;
                    log = $"You can now use {s.actionName}";
                }
            }
        }
        else if (skill.type == SkillType.Spell) 
        { 
                head.intelligence += raise;
        }
        else if (skill.type == SkillType.Dagger) 
        {
            daggerFamiliarity += raise;
            foreach (Skill s in w.availableActions)
            {
                if (s.familiarityRequired == daggerFamiliarity)
                {
                    upgrade = true;
                    log = $"You can now use {s.actionName}";
                }
            }
        }
        else if (skill.type == SkillType.Fist) 
        {
            fistFamiliarity += raise;
            foreach (Skill s in w.availableActions)
            {
                if (s.familiarityRequired == fistFamiliarity)
                {
                    upgrade = true;
                    log = $"You can now use {s.actionName}";
                }
            }
        }
        else if (skill.type == SkillType.Shield) 
        {
            shieldFamiliarity += raise;
            foreach (Skill s in w.availableActions)
            {
                if (s.familiarityRequired == shieldFamiliarity)
                {
                    upgrade = true;
                    log = $"You can now use {s.actionName}";
                }
            }
        }
        else if (skill.type == SkillType.Sword) 
        {
            swordFamiliarity += raise;
            foreach (Skill s in w.availableActions)
            {
                if (s.familiarityRequired == swordFamiliarity)
                {
                    upgrade = true;
                    log = $"You can now use {s.actionName}";
                }
            }
        }
        else if (skill.type == SkillType.GreatAxe) 
        {
            greatAxeFamiliarity += raise;
            foreach (Skill s in w.availableActions)
            {
                if (s.familiarityRequired == greatAxeFamiliarity)
                {
                    upgrade = true;
                    log = $"You can now use {s.actionName}";
                }
            }
        }
        else if (skill.type == SkillType.GreatSword) 
        {
            greatSwordFamiliarity += raise;
            foreach (Skill s in w.availableActions)
            {
                if (s.familiarityRequired == greatSwordFamiliarity)
                {
                    upgrade = true;
                    log = $"You can now use {s.actionName}";
                }
            }
        }
        CombatLog.instance.UpdateLog($"Your familiarity with {w.weaponName} has increaed by {raise}!");
        if(upgrade) CombatLog.instance.UpdateLog(log);
    }
    public void RaiseSkill(Skill skill,int x)
    {
        foreach (Skill s in GameManager.instance.player.player.skills)
        {
            if (s.skillName.Contains(skill.skillName)) s.level+=x;
        }
        CombatLog.instance.UpdateLog($"Your skill in {skill.actionName} has raised by {x}");
    }
}