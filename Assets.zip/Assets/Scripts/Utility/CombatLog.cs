using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CombatLog : MonoBehaviour
{
    public static CombatLog instance;
    public Text log;
    public List<string> text;
    private void Awake()
    {
        instance = this;
    }

    public void UpdateLog(string line)
    {        
        if (text.Count < 17)
        {
            text.Add(line);
        }
        else
        {
            for (int i = 0; i < 16; i++)
            {
                text[i] = text[i + 1];
            }
            text[16] = line;
        }
        log.text = "";
        foreach(string s in text)
        {
            log.text += s + "\n";
        }
    }

    internal void FreshLog(string line)
    {
        log.text = line;
    }

    internal void Clean()
    {
        CombatLog.instance.text.Clear();
        log.text = "";
    }
}
