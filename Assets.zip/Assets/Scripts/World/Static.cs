using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Data", menuName = "Static", order = 1)]
public class Static : ScriptableObject
{
    public string terrainName;
    public List<string> description;
    public Sprite sprite;
}