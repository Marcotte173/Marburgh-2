﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Arm : Body
{
    public Arm otherArm;
    public int strength;
    public int coordination;
    public Weapon weapon;
    public Button button;
    public Dropdown dropDown;
    public Text text;
    public SpriteRenderer weaponImage;
    Quaternion q;

    private void Start()
    {
        if (source.player != null) button.GetComponent<Image>().sprite = weapon.sprite;
        q = weaponImage.GetComponent<Transform>().rotation;
    }
    public void Equip(Weapon newWeapon)
    {        
        weapon = newWeapon;
        if (source.player != null) button.GetComponent<Image>().sprite = weapon.sprite;
        if(weapon.weaponName != ItemList.instance.rightFist.weaponName && weapon.weaponName != ItemList.instance.leftFist.weaponName)weaponImage.sprite = weapon.sprite;
        else weaponImage.sprite = ItemList.instance.none.sprite;        
    }

    public void MoveWeaponImage()
    {
        if (weapon.weaponName.Contains("Bow"))
        {
            if (source.leftArm == this)
            {
                weaponImage.GetComponent<Transform>().position = new Vector3(GetComponent<Transform>().position.x + 0.313f, GetComponent<Transform>().position.y + -0.1f, GetComponent<Transform>().position.z);
                weaponImage.GetComponent<Transform>().rotation = new Quaternion(GetComponent<Transform>().rotation.x, GetComponent<Transform>().rotation.y, GetComponent<Transform>().rotation.z, GetComponent<Transform>().rotation.w);
            }
            else
            {
                weaponImage.GetComponent<Transform>().position = new Vector3(GetComponent<Transform>().position.x - 0.313f, GetComponent<Transform>().position.y + -0.1f, GetComponent<Transform>().position.z);
                weaponImage.GetComponent<Transform>().rotation = new Quaternion(GetComponent<Transform>().rotation.x, GetComponent<Transform>().rotation.y - 180, GetComponent<Transform>().rotation.z, GetComponent<Transform>().rotation.w);
            }
        }
        else
        {
            if (source.leftArm == this)
            {
                weaponImage.GetComponent<Transform>().position = new Vector3(GetComponent<Transform>().position.x + 0.438f, GetComponent<Transform>().position.y + 0.145f, GetComponent<Transform>().position.z);
                weaponImage.GetComponent<Transform>().rotation = GameManager.instance.q1;
            }
            else
            {
                weaponImage.GetComponent<Transform>().position = new Vector3(GetComponent<Transform>().position.x - 0.438f, GetComponent<Transform>().position.y + 0.145f, GetComponent<Transform>().position.z);
                weaponImage.GetComponent<Transform>().rotation = GameManager.instance.q2;
            }
        }
    }
    public override void Destroyed()
    {
        if(source.player != null && weapon.weaponName!= "Fist")
        {
            CombatLog.instance.UpdateLog($"You drop your {weapon.weaponName} on the floor!");
            Dungeon.instance.currentFloor.currentRoom.Spawn(source.location.x, source.location.y, weapon, null, null, null);
            if (this == source.leftArm)
            {
                Equip(ItemList.instance.leftFist);
                source.player.inventory[13].weapon = ItemList.instance.leftFist;
            }   
            else
            {
                Equip(ItemList.instance.rightFist);
                source.player.inventory[14].weapon = ItemList.instance.rightFist;
            }            
        }
        base.Destroyed();
        weaponImage.sprite = ItemList.instance.none.sprite;
    }

    internal void Coordinate(int x)
    {
        coordination += x;
        if(x>0) CombatLog.instance.UpdateLog($"Your {bodyName} is more coordinated");
        else CombatLog.instance.UpdateLog($"Your {bodyName} feels clumsy and slow");
    }
    internal void Strength(int x)
    {
        strength += x;
        if (x > 0) CombatLog.instance.UpdateLog($"Your {bodyName} is STRONGER!");
        else CombatLog.instance.UpdateLog($"Your {bodyName} grows weak");
    }
}