using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum EnemyType{Fighter, Warrior, Thief, Archer, Orc, Butcher }; 
public class Enemy : MonoBehaviour
{
    public int dropChance;
    public Agent source;
    public Weapon weapon;
    public Armor armor;
    public Drop drop;
    public bool dropsGold;
    public bool dropsPotions;
    public EnemyType type;
    public List<Weapon> weaponDropList;
    public List<Armor> armorDropList;
    public List<Drop> dropList;
    public Location startingLocation;
    public Weapon[] equippedWeapons;
    public Armor[] equippedArmor;
    private void Start()
    {
        List<int> dropOptions = new List<int> { };
        if (weaponDropList.Count != 0) dropOptions.Add(0);
        if (armorDropList.Count != 0) dropOptions.Add(1);
        if (dropsPotions) dropOptions.Add(2);
        if (dropsGold) dropOptions.Add(3);
        if (dropList.Count!=0) dropOptions.Add(4);
        if(dropOptions.Count != 0)
        {
            int roll = Return.Int(0, dropOptions.Count);
            if (dropOptions[roll] == 0)
            {
                weapon = weaponDropList[Return.Int(0, weaponDropList.Count)];
            }
            else if (dropOptions[roll] == 1)
            {
                armor = armorDropList[Return.Int(0, armorDropList.Count)];
            }
            else if (dropOptions[roll] == 2)
            {
                drop = Potion.instance.potions[Return.Int(0, Potion.instance.potions.Count)];
            }
            else if (dropOptions[roll] == 3)
            {
                Drop d = Instantiate(ItemList.instance.gold);
                d.value = Return.Int(15, 35);
                drop = d;
            }
            else if (dropOptions[roll] == 4)
            {
                drop = dropList[Return.Int(0, dropList.Count)];
            }
        }        
        if (equippedWeapons[0] != null) source.leftArm.Equip(GameManager.instance.CreateNewWeapon(equippedWeapons[0]));
        if (equippedWeapons[1] != null) source.rightArm.Equip(GameManager.instance.CreateNewWeapon(equippedWeapons[1]));
        if (equippedArmor[0] != null) source.head.armor.Equip(GameManager.instance.CreateNewArmor(equippedArmor[0]));
        if (equippedArmor[1] != null) source.body.armor.Equip(GameManager.instance.CreateNewArmor(equippedArmor[1]));
        if (equippedArmor[2] != null) source.leftArm.armor.Equip(GameManager.instance.CreateNewArmor(equippedArmor[2]));
        if (equippedArmor[3] != null) source.rightArm.armor.Equip(GameManager.instance.CreateNewArmor(equippedArmor[3]));
        if (equippedArmor[4] != null) source.legs.armor.Equip(GameManager.instance.CreateNewArmor(equippedArmor[4]));
    }
    public void DropGear(int x, int y)
    {
        bool willDrop = false;
        string a = (weapon!=null)?weapon.weaponName:(armor!= null)?armor.armorName:(drop!=null)?drop.dropName:"";
        if (weapon != null)
        {
            willDrop = true;
            Dungeon.instance.currentFloor.currentRoom.Spawn(x, y, weapon, null, null, null);
        }
        else if (armor != null)
        {
            willDrop = true;
            Dungeon.instance.currentFloor.currentRoom.Spawn(x, y, null, armor, null, null);
        }
        else if (drop != null)
        {
            willDrop = true;
            Dungeon.instance.currentFloor.currentRoom.Spawn(x, y, null, null, drop, null);
        }
        if(willDrop) CombatLog.instance.UpdateLog($"{GetComponent<Agent>().agentName} dropped {a} on death!");
    }
}
