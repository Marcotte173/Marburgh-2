using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fountain : MonoBehaviour
{
    public bool corrupted;
    public bool used;
    private void Start()
    {
        if (Return.Int(0, 10) == 9)
        {
            corrupted = true;
            GetComponent<Item>().terrain.description = new List<string>
            {
                "You are looking at what was once a beautiful fountain",
                "Foul liquid collects in pools at the near the base",
                "It smells... not good",
                "Press F to drink from the fountain"
            };
            GetComponent<Item>().terrain.triggerString = new List<string>
            {
                "I'm not sure what made you think this was a good Idea",
                "You drink the fetid water and start to feel very sick"
            };
        }
    }
    public void Use()
    {
        if (!used)
        {
            if (!corrupted)
            {
                if (GameManager.instance.player.head.status != Status.Undamaged) GameManager.instance.player.head.ChangeHealth(0, true);
                if (GameManager.instance.player.body.status != Status.Undamaged) GameManager.instance.player.body.ChangeHealth(0, true);
                if (GameManager.instance.player.leftArm.status != Status.Undamaged) GameManager.instance.player.leftArm.ChangeHealth(0, true);
                if (GameManager.instance.player.rightArm.status != Status.Undamaged) GameManager.instance.player.rightArm.ChangeHealth(0, true);
                if (GameManager.instance.player.legs.status != Status.Undamaged) GameManager.instance.player.legs.ChangeHealth(0, true);
            }
            else
            {
                if (GameManager.instance.player.head.status != Status.Destroyed) GameManager.instance.player.head.ChangeHealth((int)GameManager.instance.player.head.status + 2, false);
                if (GameManager.instance.player.body.status != Status.Destroyed) GameManager.instance.player.body.ChangeHealth((int)GameManager.instance.player.body.status + 2, false);
                if (GameManager.instance.player.leftArm.status != Status.Destroyed) GameManager.instance.player.leftArm.ChangeHealth((int)GameManager.instance.player.leftArm.status + 2, false);
                if (GameManager.instance.player.rightArm.status != Status.Destroyed) GameManager.instance.player.rightArm.ChangeHealth((int)GameManager.instance.player.rightArm.status + 2, false);
                if (GameManager.instance.player.legs.status != Status.Destroyed) GameManager.instance.player.legs.ChangeHealth((int)GameManager.instance.player.legs.status + 2, false);
            }
            GetComponent<Item>().terrain.description = new List<string>
            {
                "You are looking at an empty fountain",
                "There is nothing left to do here"
            };
            used = true;
        }          
        
    }
}
