using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Names : MonoBehaviour
{
    public static Names instance;
    private void Awake()
    {
        instance = this;
    }
    public List<string> list = new List<string>
    {
            "Adam","Alex","Anthony","Alistair","Alfred","Austin",
            "Beuford", "Bernard", "Bill", "Bryce", "Barrie",
            "Cole", "Charles","Chris","Chance", "Caleb","Caddie", "Connor", "Carl","Cory","Cody",
            "Doug",  "Don", "Dwight", "Dexter", "Devon",
            "Edward", "Eric",
            "Fred","Frank", 
             "George", "Gerald",
              "Harold","Hank",
             "Ian",
              "Jake", "James", "Jackson", "Jesse", "John", "Jack", 
             "Karl", "Keon", "Kevan",
            "Lewis","Larry",
             "Matt","Martin","Melvin", "Maddox","Meagen","Marvin","Mitch","Micah","Mark","Micheal",
            "Oliver","Oscar","Odyn",
            "Paul","Pierce",            
            "Wesley"
    };
    public List<string> otherList = new List<string>
    {
        "Angela","Amy", "Anna","Alison","Alexa","Ainsley","Beth", "Bonnie", "Bailey","Barbara","Belle","Carol", "Candice", "Cindy","Caitlyn","Donna", "Deborah","Daphne","Elaine", 
        "Emily","Farrah","Fran","Gina","Heather","Isabelle","Jolene","Janet", "Gina","Kyra","Katherine","Laura","Mary","Maebel","Magda","Mia","Olivea","Piper","Pam","Sara"
    };
}
