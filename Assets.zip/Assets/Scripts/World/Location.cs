﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

public class Location : MonoBehaviour
{
    public int x;
    public int y;
    public float g;
    public float h;
    public float f;
    public Location parent;
    public Agent occupiedBy;
    public List<Location> neighbor;
    public int cost;
    public string description;
    public bool locked;
}