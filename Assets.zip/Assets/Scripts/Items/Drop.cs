using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum DropType { Gold,Potion,Book,Key };

[CreateAssetMenu(fileName = "Data", menuName = "Drop", order = 1)]
public class Drop : ScriptableObject
{
    public string dropName;
    public int level;
    public int value;
    public DropType type;
    public Skill skill;
    public bool shop;
    public Sprite sprite;
    public string flavor;
}
