﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{    
    public int damageRatio;
    public int healthRatio;
    public int armorRatio;
    public Agent agent;
    public Agent player;
    public static GameManager instance;
    public Location location;
    public GameObject grid;
    public List<Location> occupied;
    public GameObject arena;
    public GameObject playerSetup;
    public GameObject title;
    public Skill noTarget;
    public Skill fireDamage;
    public List<Sprite> floor;
    public Sprite wall;
    public Sprite door;
    public Sprite lockedDoor;
    public Sprite upStair;
    public Sprite downStair;
    public Item item;
    public Weapon w1 = null;
    public Weapon w2 = null;
    public Armor a1 = null;
    public Armor a2 = null;
    public Drop d1 = null;
    public Drop d2 = null;
    public InputField nameField;
    public int playerClass = 0;
    public List<Toggle> classes;
    public Sprite breakShield;
    public Sprite rendArmor;
    public Sprite carefulShot;
    public Sprite doubleShot;
    public Sprite knockdown;
    public Sprite haymaker;
    public Sprite uppercut;
    public Quaternion q1;
    public Quaternion q2;
    public GameObject dungeonObject;
    public GameObject options;

    private void Awake()
    {
        instance = this;
        Title();
    }

    public void Title()
    {
        TurnOn(title);
        TurnOff(arena);
        TurnOff(playerSetup);
    }

    public void NewGame()
    {
        playerClass = 0;
        classes[0].isOn = true;
        foreach (Toggle t in classes) if (t != classes[0]) t.isOn = false;
        CombatLog.instance.Clean();
        if (player != null) Destroy(player.gameObject);
        if (Dungeon.instance.floors.Count > 0)
        {
            foreach (Floor f in Dungeon.instance.floors) Destroy(f.gameObject);
        }
        Dungeon.instance.floors.Clear();
        Dungeon.instance.currentFloor = null;
        PlayerSetup();
        GameManager.instance.TurnOff(player.player.recap);
    }
    public void Quit()
    { 
        //UnityEditor.EditorApplication.isPlaying = false;
        Application.Quit();
    }
    public void Options()
    {
        if (options.activeSelf) TurnOff(options);
        else TurnOn(options);
    }
    public void Arena()
    {
        if (nameField.text != "") player.agentName = nameField.text;
        else player.agentName = "Marcotte";
        player.nameText.text = player.agentName;
        TurnOff(title);
        TurnOn(arena);
        TurnOff(playerSetup);
        Dungeon.instance.CreateWorld();
        player.transform.position = new Vector2(3, 3);
        FindLocation();
        PlayerInput.instance.MakeSkillDropDowns();
        player.decisions.UpdateAvailableDecisions();
        TurnOn(player.player.bag.gameObject);
        TurnOn(player.player.character.gameObject);
        TurnOn(player.legs.button.gameObject);
        TurnOn(player.legs.dropDown.gameObject);
        TurnOn(player.legs.text.gameObject);
        TurnOn(player.head.button.gameObject);
        TurnOn(player.head.dropDown.gameObject);
        TurnOn(player.head.text.gameObject);
        TurnOn(player.leftArm.button.gameObject);
        TurnOn(player.leftArm.dropDown.gameObject);
        TurnOn(player.leftArm.text.gameObject);
        TurnOn(player.rightArm.button.gameObject);
        TurnOn(player.rightArm.dropDown.gameObject);
        TurnOn(player.rightArm.text.gameObject);
        PlayerInput.instance.combatOn = true;
        EquipPlayer();
        UpdateSprites();
    }
    public void PlayerSetup()
    {
        TurnOff(title);
        TurnOff(arena);
        TurnOn(playerSetup);
        playerSummon();
        CreateSkills();
        TurnOffButtons();
        PlayerInput.instance.combatOn = false;
        classes[0].isOn = true ;
    }

    public void TurnOffButtons()
    {
        TurnOff(player.player.bag.gameObject);
        TurnOff(player.player.character.gameObject);
        TurnOff(player.spell.castObject);
        TurnOff(player.castObject);
        TurnOff(player.legs.button.gameObject);
        TurnOff(player.legs.dropDown.gameObject);
        TurnOff(player.legs.text.gameObject);
        TurnOff(player.head.button.gameObject);
        TurnOff(player.head.dropDown.gameObject);
        TurnOff(player.head.text.gameObject);
        TurnOff(player.leftArm.button.gameObject);
        TurnOff(player.leftArm.dropDown.gameObject);
        TurnOff(player.leftArm.text.gameObject);
        TurnOff(player.rightArm.button.gameObject);
        TurnOff(player.rightArm.dropDown.gameObject);
        TurnOff(player.rightArm.text.gameObject);
    }

    private void CreateSkills()
    {
        player.greatAxeFamiliarity = 1;
        player.greatSwordFamiliarity = 1;
        player.swordFamiliarity =1 ;
        player.fistFamiliarity = 1;
        player.shieldFamiliarity = 1;
        player.axeFamiliarity = 1;
        player.bowFamiliarity = 1;
        player.daggerFamiliarity = 1;
        player.legFamiliarity = 1;
    }

    public void SkillAdd(Skill skillToAdd, Agent agent)
    {
        Skill s = Instantiate(skillToAdd);
        s.name = skillToAdd.name;
        agent.head.knownActions.Add(s);
    }
    public void SkillAdd(Skill skillToAdd,bool head,Agent agent)
    {
        Skill s = Instantiate(skillToAdd);
        s.name = skillToAdd.name;
        agent.head.headActions.Add(s);
    }

    public void TurnOff(GameObject g)
    {
        if (g.activeSelf) g.SetActive(false);
    }

    public void TurnOn(GameObject g)
    {
        if (!g.activeSelf) g.SetActive(true);
    }

    public void playerSummon()
    {
        Formulas.DetermineHealth();
        Agent a = Instantiate(agent);
        a.transform.position = new Vector2(1, -10);
        a.gameObject.name = "player";
        player = a;
        a.flavor.Add("You are looking at yourself");
        a.flavor.Add("You handsome devil");        
        PlayerInput.instance.source = a;
        a.player.CreateInventory();
        a.player.CreateShop();
        q1 = a.leftArm.weaponImage.GetComponent<Transform>().rotation;
        q2 = a.rightArm.weaponImage.GetComponent<Transform>().rotation;
    }

    public void FindLocation()
    {
        occupied.Clear();
        foreach (Location l in Dungeon.instance.currentFloor.currentRoom.tileList) l.occupiedBy = null;
        foreach (Agent a in Dungeon.instance.currentFloor.currentRoom.agentList)
        {
            foreach (Location l in Dungeon.instance.currentFloor.currentRoom.tileList)
            {
                if (a.transform.position.x == l.x && a.transform.position.y == l.y)
                {
                    a.location = l;
                    occupied.Add(l);
                    l.occupiedBy = a;
                }
            }
        }
    }
    public void EndTurn()
    {
        player.moved = true;
        FindLocation();
        PlayerInput.instance.loadSkill = null;
        PlayerInput.instance.loadArm = null;
        PlayerInput.instance.loadWeapon = null;
        PlayerInput.instance.loadHead = false;
        PlayerInput.instance.loadLegs = false;        
        foreach (Agent a in Dungeon.instance.currentFloor.currentRoom.agentList)
        {
            if (!a.moved)
            {
                if (a.knockedDown>0)
                {
                    CombatLog.instance.UpdateLog(Return.AgentName(a, true, false) + " was knocked down and will spend their turn getting up");
                    a.knockedDown--;
                }
                else TakeTurn(a);
            }
        }
        foreach (Agent a in Dungeon.instance.currentFloor.currentRoom.agentList)
        {
            a.moved = false;
            if (a.onFire>0)
            {
                CombatLog.instance.UpdateLog(Return.AgentName(a, true, false) + Return.Grammar(a,"take") +" burning damage");
                Formulas.Target(a,player.player.skills[37]).TakeDamage(Formulas.Damage(a.fireDamage),true);
                a.onFire--;
                GameManager.instance.player.whoHitMeLast = "Burning";
            }
        }
        player.decisions.UpdateAvailableDecisions();
        if (player.player.inventory[8].armor != null) player.player.inventory[8].armor.hp =   player.head.armor.hp;
        if (player.player.inventory[9].armor != null) player.player.inventory[9].armor.hp =   player.body.armor.hp;
        if (player.player.inventory[10].armor != null) player.player.inventory[10].armor.hp = player.leftArm.armor.hp;
        if (player.player.inventory[11].armor != null) player.player.inventory[11].armor.hp = player.rightArm.armor.hp;
        if (player.player.inventory[12].armor != null) player.player.inventory[12].armor.hp = player.legs.armor.hp;
        UpdateSprites();
        CombatLog.instance.text.Clear();
    }

    public void TakeTurn(Agent a)
    {
        a.target = player;
        a.decisions.UpdateAvailableDecisions();
        a.decisions.Enemy();
        FindLocation();
    }

    public void UpdateSprites()
    {
        Player theplayer = player.player;
        foreach (Agent a in Dungeon.instance.currentFloor.currentRoom.agentList)
        {            
            a.leftArm.MoveWeaponImage();
            a.rightArm.MoveWeaponImage();
            a.head.UpdateBody();
            a.leftArm.UpdateBody();
            a.rightArm.UpdateBody();
            a.body.UpdateBody();
            a.legs.UpdateBody();
            a.head.armor.UpdateArmor();
            a.leftArm.armor.UpdateArmor();
            a.rightArm.armor.UpdateArmor();
            a.body.armor.UpdateArmor();
            a.legs.armor.UpdateArmor();
            if (a == GameManager.instance.player)
            {                
                a.leftArm.button.GetComponent<Image>().sprite = a.leftArm.weapon.sprite;
                a.rightArm.button.GetComponent<Image>().sprite = a.rightArm.weapon.sprite;
            }
        }
        foreach (Item i in theplayer.inventory) i.ChangeInventorySprite();
        for (int i = 0; i < 8; i++)
        {
            if (theplayer.inventory[i].weapon != null) theplayer.text[11 + i].text = theplayer.inventory[i].weapon.weaponName;
            else if (theplayer.inventory[i].armor != null) theplayer.text[11 + i].text = theplayer.inventory[i].armor.armorName;
            else if (theplayer.inventory[i].drop != null) theplayer.text[11 + i].text = theplayer.inventory[i].drop.dropName;
            else theplayer.text[11 + i].text ="";
        }
        for (int i = 8; i < 13; i++)
        {
            if (theplayer.inventory[i].armor != null) theplayer.text[11 + i].text = theplayer.inventory[i].armor.armorName;
            else theplayer.text[11 + i].text = theplayer.inventory[i].name;
        }
        theplayer.text[24].text = theplayer.inventory[13].weapon.weaponName;
        theplayer.text[25].text = theplayer.inventory[14].weapon.weaponName;
        theplayer.text[26].text = (theplayer.box2.isActiveAndEnabled) ? "Sell" : "";
        theplayer.text[1].text = Return.ItemName(theplayer.shop[0]);
        theplayer.text[2].text = Return.ItemValue(theplayer.shop[0]).ToString() + " Gold";
        theplayer.text[3].text = Return.ItemName(theplayer.shop[1]);
        theplayer.text[4].text = Return.ItemValue(theplayer.shop[1]).ToString() + " Gold";
        theplayer.text[5].text = Return.ItemName(theplayer.shop[2]);
        theplayer.text[6].text = Return.ItemValue(theplayer.shop[2]).ToString() + " Gold";
        theplayer.text[7].text = Return.ItemName(theplayer.shop[3]);
        theplayer.text[8].text = Return.ItemValue(theplayer.shop[3]).ToString() + " Gold";
        theplayer.text[9].text = Return.ItemName(theplayer.shop[4]);
        theplayer.text[10].text = Return.ItemValue(theplayer.shop[4]).ToString() + " Gold";
        theplayer.text[27].text = "Intelligence: " + player.head.intelligence.ToString();
        theplayer.text[28].text = "Movement: " + player.legs.movement.ToString();
        theplayer.text[30].text = "Strength: " + player.leftArm.strength.ToString();
        theplayer.text[29].text = "Coordination: " + player.leftArm.coordination.ToString();
        theplayer.text[31].text = "Strength: " + player.rightArm.strength.ToString();
        theplayer.text[32].text = "Coordination: " + player.rightArm.coordination.ToString();        
        theplayer.text[33].text = $"Axe: {player.axeFamiliarity}";
        theplayer.text[33].text += $"\nBow: {player.bowFamiliarity}";
        theplayer.text[33].text += $"\nDagger: {player.daggerFamiliarity}";
        theplayer.text[33].text += $"\nFist: {player.fistFamiliarity}";
        theplayer.text[33].text += $"\nGreat Axe: {player.greatAxeFamiliarity}";
        theplayer.text[33].text += $"\nGreat Sword: {player.greatSwordFamiliarity}";
        theplayer.text[33].text += $"\nLeg: {player.legFamiliarity}";
        theplayer.text[33].text += $"\nShield: {player.shieldFamiliarity}";
        theplayer.text[33].text += $"\nSword: {player.swordFamiliarity}";
        theplayer.text[34].text = player.leftArm.weapon.weaponName;
        theplayer.text[35].text = "";
        List<Skill> lhs = player.decisions.GetSkills(player.leftArm.weapon.availableActions, player.leftArm);
        foreach (Skill s in lhs) theplayer.text[35].text += $"\n{s.actionName}: {Return.SkillLevel(s)}";
        theplayer.text[36].text = player.rightArm.weapon.weaponName;
        List<Skill> rhs = player.decisions.GetSkills(player.rightArm.weapon.availableActions, player.rightArm);
        theplayer.text[37].text = "";
        foreach (Skill s in rhs) theplayer.text[37].text += $"\n{s.actionName}: {Return.SkillLevel(s)}";
        theplayer.text[38].text = player.agentName;
        //Spells
        theplayer.text[40].text = "";
        int flame = 0;
        bool headFlame = false;
        bool rArmFlame = false;
        bool lArmFlame = false;
        foreach (Skill s in player.head.headActions) if (s.skillName.Contains("Flame")) headFlame = true;
        foreach (Skill s in player.leftArm.weapon.availableActions) if (s.skillName.Contains("Flame")) lArmFlame = true;
        foreach (Skill s in player.rightArm.weapon.availableActions) if (s.skillName.Contains("Flame")) rArmFlame = true;
        if (headFlame || rArmFlame || lArmFlame)
        {
            if (headFlame) flame++;
            if (lArmFlame) flame++;
            if (rArmFlame) flame++;
            theplayer.text[40].text = $"Flame: {flame}/3";
        }
        else theplayer.text[40].text += "No spells";
        //
        theplayer.text[0].text = theplayer.gold + " Gold";
        theplayer.text[41].text = theplayer.gold + " Gold";
        theplayer.text[39].text = $"Dungeon Level: {Dungeon.instance.currentFloor.floorNumber}";
        theplayer.characterScreenLefttWeapon.sprite = player.leftArm.weapon.sprite;
        theplayer.characterScreenRightWeapon.sprite = player.rightArm.weapon.sprite;
        foreach (Item i in theplayer.shop) i.ChangeInventorySprite();
        foreach (Item i in Dungeon.instance.currentFloor.currentRoom.items) i.ChangeSprite();
    }

    public void AddToItem(Weapon w, Item item2)
    {
        item2.weapon = w;
    }
    public void AddToItem(Armor a, Item item2)
    {
        item2.armor = a;
    }
    public void AddToItem(Drop d, Item item2)
    {
        item2.drop = d;
    }
    
    public void UseInventory(Item item1, Item item2)
    {
        Weapon oldWeaponLeft = player.leftArm.weapon;
        Weapon oldWeaponRight = player.rightArm.weapon;
        if (item1.drop != null && !IsForSale(item1))
        {
            UseItem(item1,item2);
        }        
        //Throwing Out an Item
        else if (item2 == player.player.inventory[15])
        {
            NullifyItem(item1);
        }
        //Selling an Item
        else if (item2 == player.player.inventory[16])
        {
            int v = 0;
            string vString = "";
            if (item1.weapon != null)
            {
                v = item1.weapon.value;
                vString = item1.weapon.weaponName;
            }
            if (item1.armor != null)
            {
                v = item1.armor.value;
                vString = item1.armor.armorName;
            }
            if (item1.drop != null)
            {
                v = item1.drop.value;
                vString = item1.drop.dropName;
            }
            CombatLog.instance.UpdateLog($"You sell your {vString} for {v/2} gold");
            player.player.gold += v/2;
            NullifyItem(item1);
        }
        //Buying an Item
        else if (IsForSale(item1) && item2 != player.player.inventory[16] && item2 != player.player.inventory[15])
        {
            int v = 0;
            string vString = "";
            int x = 0;
            if (item1.weapon != null)
            {
                v = item1.weapon.value;
                vString = item1.weapon.weaponName;
            }
            if (item1.armor != null)
            {
                v = item1.armor.value;
                vString = item1.armor.armorName;
                x = 1;
            }
            if (item1.drop != null)
            {
                v = item1.drop.value;
                vString = item1.drop.dropName;
                x = 2;
            }
            if (Return.CanAfford(v))
            {
                if (item1.weapon != null ) item1.weapon.shop =false;
                if (item1.armor != null )  item1.armor.shop =false;
                if (item1.drop != null) item1.drop.shop = false; 
                CombatLog.instance.UpdateLog($"You buy the {vString} for {v} gold");
                player.player.gold -= v;
                if (x == 2 && IsArmorSlot(item2)) UseItem(item1, item2);
                else SwapItems(item2, item1);
            }
            else CombatLog.instance.UpdateLog($"You cannot afford the {vString}");
        }
        else
        {
            SwapItems(item1,item2);            
        }
        if (player.player.inventory[13].weapon == null) player.player.inventory[13].weapon = ItemList.instance.leftFist;
        if (player.player.inventory[14].weapon == null) player.player.inventory[14].weapon = ItemList.instance.rightFist;
        ArmorEquip();
        player.EquipWeapons(player.player.inventory[13].weapon, player.player.inventory[14].weapon,oldWeaponLeft,oldWeaponRight);
        UpdateSprites();
    }

    private void UseItem(Item item1, Item item2)
    {
        if (item1.drop.type == DropType.Book && IsArmorSlot(item2) && !item1.drop.shop)
        {
            AddSpell(item1);
            NullifyItem(item1);
        }
        else if (item1.drop.type == DropType.Potion && IsArmorSlot(item2))
        {
            Potion.instance.UsePotion(item1.drop.level, WhatBodyPart(item2));
            NullifyItem(item1);
        }
    }

    private bool IsForSale(Item item1)
    {
        if (item1.weapon != null && item1.weapon.shop) return true;
        if (item1.armor != null && item1.armor.shop) return true;
        if (item1.drop != null && item1.drop.shop) return true;
        return false;
    }

    private void AddSpell(Item item1)
    {
        //Check to see if you can use
        int canUse = 0;
        foreach (Skill skillCheck in player.head.headActions) if (skillCheck.skillName.Contains(item1.drop.skill.skillName)) canUse++;
        foreach (Skill skillCheck in ItemList.instance.leftFist.availableActions) if (skillCheck.skillName.Contains(item1.drop.skill.skillName)) canUse++;
        foreach (Skill skillCheck in ItemList.instance.rightFist.availableActions) if (skillCheck.skillName.Contains(item1.drop.skill.skillName)) canUse++;
        //
        if (canUse<3)
        {
            int x = Return.Int(0, 3);
            if (x == 0)
            {
                bool tryAgain = false;
                foreach (Skill skillCheck in player.head.headActions) if (skillCheck.skillName.Contains(item1.drop.skill.skillName)) tryAgain = true;
                if (tryAgain) AddSpell(item1);
                else
                {
                    Skill s = Instantiate(item1.drop.skill);
                    s.name = item1.drop.skill.name;
                    s.skillName += " Head";
                    SkillAdd(s, true,player);
                    CombatLog.instance.UpdateLog("You read the book, memorizing the words of power.");
                    CombatLog.instance.UpdateLog($"You can now cast {item1.drop.skill.actionName}");
                }
            }
            else if (x == 1 || x == 2)
            {
                if (!player.head.knownActions.Contains(item1.drop.skill)) SkillAdd(item1.drop.skill,player);
                if (x == 1)
                {
                    bool tryAgain = false;
                    foreach (Skill skillCheck in ItemList.instance.leftFist.availableActions) if (skillCheck.skillName.Contains(item1.drop.skill.skillName)) tryAgain = true;
                    if (tryAgain) AddSpell(item1);
                    else
                    {
                        Skill s = Instantiate(item1.drop.skill);
                        s.name = item1.drop.skill.name;
                        s.skillName += " Left Hand";
                        ItemList.instance.leftFist.availableActions.Add(s);
                        CombatLog.instance.UpdateLog("From the book, you learn complex gestures involving your left hand");
                        if (player.player.inventory[13].weapon.weaponName == "Fist") player.player.inventory[13].weapon = ItemList.instance.leftFist;
                        CombatLog.instance.UpdateLog($"You can now cast {item1.drop.skill.actionName}");
                    }
                }
                else
                {
                    bool tryAgain = false;
                    foreach (Skill skillCheck in ItemList.instance.rightFist.availableActions) if (skillCheck.skillName.Contains(item1.drop.skill.skillName)) tryAgain = true;
                    if (tryAgain) AddSpell(item1);
                    else
                    {
                        Skill s = Instantiate(item1.drop.skill);
                        s.name = item1.drop.skill.name;
                        s.skillName += " Right Hand";
                        ItemList.instance.rightFist.availableActions.Add(s);
                        CombatLog.instance.UpdateLog("From the book, you learn complex gestures involving your right hand");
                        if (player.player.inventory[14].weapon.weaponName == "Fist") player.player.inventory[14].weapon = ItemList.instance.rightFist;
                        CombatLog.instance.UpdateLog($"You can now cast {item1.drop.skill.actionName}");
                    }
                }
            }
        }    
        else CombatLog.instance.UpdateLog($"You have learned all you can from this book. You throw it away.");
    }

    private void SwapItems(Item item1, Item item2)
    {
        Weapon w1 = null;
        Weapon w2 = null;
        Armor a1 = null;
        Armor a2 = null;
        Drop d1 = null;
        Drop d2 = null;
        if (item1.weapon != null && item1.weapon.weaponName != "Fist")
        {
            w1 = item1.weapon;
        }
        if (item2.weapon != null && item2.weapon.weaponName != "Fist")
        {
            w2 = item2.weapon;
        }
        if (item1.armor != null)
        {
            a1 = item1.armor;
            a1.hp = item1.armor.hp;
        }
        if (item2.armor != null)
        {
            a2 = item2.armor;
            a2.hp = item2.armor.hp;
        }
        if (item1.drop != null) d1 = item1.drop;
        if (item2.drop != null) d2 = item2.drop;
        NullifyItem(item1);
        NullifyItem(item2);
        if (w1 != null) AddToItem(w1, item2);
        if (w2 != null) AddToItem(w2, item1);
        if (a1 != null) AddToItem(a1, item2);
        if (a2 != null) AddToItem(a2, item1);
        if (d1 != null) AddToItem(d1, item2);
        if (d2 != null) AddToItem(d2, item1);
    }

    private Body WhatBodyPart(Item item)
    {
        if (item == player.player.inventory[8]) return player.head;
        if (item == player.player.inventory[9]) return player.body;
        if (item == player.player.inventory[10]) return player.leftArm;
        if (item == player.player.inventory[11]) return player.rightArm;
        if (item == player.player.inventory[12]) return player.legs;
        return null;
    }

    private bool IsArmorSlot(Item item)
    {
        if (item == player.player.inventory[8]) return true;
        if (item == player.player.inventory[9]) return true;
        if (item == player.player.inventory[10]) return true;
        if (item == player.player.inventory[11]) return true;
        if (item == player.player.inventory[12]) return true;
        return false;
    }

    public void ArmorEquip()
    {
        if (player.player.inventory[8].armor != null) player.head.armor.Equip(player.player.inventory[8].armor);
        else player.head.armor.Equip(ItemList.instance.none);
        if (player.player.inventory[9].armor != null) player.body.armor.Equip(player.player.inventory[9].armor);
        else player.body.armor.Equip(ItemList.instance.none);
        if (player.player.inventory[10].armor != null) player.leftArm.armor.Equip(player.player.inventory[10].armor);
        else player.leftArm.armor.Equip(ItemList.instance.none);
        if (player.player.inventory[11].armor != null) player.rightArm.armor.Equip(player.player.inventory[11].armor);
        else player.rightArm.armor.Equip(ItemList.instance.none);
        if (player.player.inventory[12].armor != null) player.legs.armor.Equip(player.player.inventory[12].armor);
        else player.legs.armor.Equip(ItemList.instance.none);        
        player.decisions.UpdateAvailableDecisions();
    }

    public void NullifyItem(Item i)
    {
        i.weapon = null;
        i.drop = null;
        i.terrain = null;
        i.armor = null;
    }
    public bool IsInventorySlot(Item item)
    {
        if (item == player.player.inventory[0]) return true;
        if (item == player.player.inventory[1]) return true;
        if (item == player.player.inventory[2]) return true;
        if (item == player.player.inventory[3]) return true;
        if (item == player.player.inventory[4]) return true;
        if (item == player.player.inventory[5]) return true;
        if (item == player.player.inventory[6]) return true;
        if (item == player.player.inventory[7]) return true;
        return false;
    }

    public bool Empty(Item item) => (item.weapon == null && item.armor == null && item.drop == null);

    public bool CanSwitch(Item item, Item slot)
    {
        if (slot == player.player.inventory[13] && item.weapon!= null && item.weapon.handed == Handed.Two)
        {
            CombatLog.instance.UpdateLog("You can only wield Two Handed Weapons with your Right Hand");
            return false;
        }
        if (slot == player.player.inventory[13] && player.leftArm.status == Status.Destroyed)
        {
            CombatLog.instance.UpdateLog("Your left arm is disabled. You cannot use an item with it");
            return false;
        }
        if (slot == player.player.inventory[14] && player.rightArm.status == Status.Destroyed)
        {
            CombatLog.instance.UpdateLog("Your right arm is disabled. You cannot use an item with it");
            return false;
        }
        if (item.drop != null && IsArmorSlot(slot)) return true;
        if (slot == player.player.inventory[16]) return true;
        if (slot == player.player.inventory[15]) return true;
        for (int i = 13; i < 15; i++) if (slot == player.player.inventory[i] && item.weapon != null) return true;
        if (slot == player.player.inventory[8] && item.armor != null && item.armor.slot == ArmorSlot.Head) return true;
        if (slot == player.player.inventory[9] && item.armor != null && item.armor.slot == ArmorSlot.Body) return true;
        if (slot == player.player.inventory[10] && item.armor != null && item.armor.slot == ArmorSlot.LeftArm) return true;
        if (slot == player.player.inventory[11] && item.armor != null && item.armor.slot == ArmorSlot.RightArm) return true;
        if (slot == player.player.inventory[12] && item.armor != null && item.armor.slot == ArmorSlot.Legs) return true;
        if (slot == IsInventorySlot(slot) && item == IsInventorySlot(item)) return true;
        for (int i = 0; i < 8; i++) if (slot == player.player.inventory[i] && Empty(slot)) return true;        
        return false;
    }

    public void Overlap(Item item1)
    {
        Rect rect1 = new Rect(item1.GetComponent<RectTransform>().localPosition.x, item1.GetComponent<RectTransform>().localPosition.y, item1.GetComponent<RectTransform>().rect.width, item1.GetComponent<RectTransform>().rect.height);
        Rect rect2;
        foreach (Item i in player.player.inventory)
        {
            if (i != item1)
            {
                rect2 = new Rect(i.GetComponent<RectTransform>().localPosition.x, i.GetComponent<RectTransform>().localPosition.y, i.GetComponent<RectTransform>().rect.width, i.GetComponent<RectTransform>().rect.height);
                if (rect1.Overlaps(rect2))
                {
                    if (CanSwitch(item1, i)) UseInventory(item1, i);
                    break;
                }
            }
        }
    }
    public void Peasant()
    {
        if (playerClass != 0) classes[playerClass].isOn = false;
        playerClass = 0;
    }

    public void Fighter()
    {
        if (playerClass != 1) classes[playerClass].isOn = false;
        playerClass = 1;
    }
    public void Rogue()
    {
        if (playerClass != 2) classes[playerClass].isOn = false;
        playerClass = 2;
    }
    public void Knight()
    {
        if (playerClass != 3) classes[playerClass].isOn = false;
        playerClass = 3;
    }
    public void Mage()
    {
        if (playerClass != 4) classes[playerClass].isOn = false;
        playerClass = 4;        
    }

    public void EquipPlayer()
    {
        if (playerClass == 0)
        {
            AddToItem(CreateNewArmor(ItemList.instance.clothArmor[1]), player.player.inventory[0]);
            AddToItem(CreateNewArmor(ItemList.instance.clothArmor[4]), player.player.inventory[1]);
            AddToItem(CreateNewWeapon(ItemList.instance.sword), player.player.inventory[2]);
            AddToItem(CreateNewWeapon(ItemList.instance.roundShield), player.player.inventory[3]);
            player.fistFamiliarity = 50;
        }
        else if (playerClass == 1)
        {
            AddToItem(CreateNewArmor(ItemList.instance.leatherArmor[1]), player.player.inventory[0]);
            AddToItem(CreateNewArmor(ItemList.instance.leatherArmor[4]), player.player.inventory[1]);
        }
        else if (playerClass == 2)
        {
            AddToItem(CreateNewArmor(ItemList.instance.leatherArmor[1]), player.player.inventory[0]);
            AddToItem(CreateNewArmor(ItemList.instance.leatherArmor[4]), player.player.inventory[1]);
            AddToItem(CreateNewWeapon(ItemList.instance.bow), player.player.inventory[2]);
        }
        else if (playerClass == 3)
        {
            AddToItem(CreateNewArmor(ItemList.instance.leatherArmor[0]), player.player.inventory[0]);
            AddToItem(CreateNewArmor(ItemList.instance.leatherArmor[1]), player.player.inventory[1]);
            AddToItem(CreateNewArmor(ItemList.instance.leatherArmor[2]), player.player.inventory[2]);
            AddToItem(CreateNewArmor(ItemList.instance.leatherArmor[3]), player.player.inventory[3]);
            AddToItem(CreateNewArmor(ItemList.instance.leatherArmor[4]), player.player.inventory[4]);
            AddToItem(CreateNewWeapon(ItemList.instance.sword), player.player.inventory[5]);
        }
        else if (playerClass == 4)
        {
            AddToItem(CreateNewArmor(ItemList.instance.clothArmor[4]), player.player.inventory[0]);
            AddToItem(CreateNewArmor(ItemList.instance.clothArmor[1]), player.player.inventory[1]);
            AddToItem(CreateNewDrop(ItemList.instance.bookOfFlame), player.player.inventory[2]);
        }        
    }
    public Weapon CreateNewWeapon(Weapon weapon)
    {
        Weapon w = Instantiate(weapon);
        w.name = weapon.name;
        return w;
    }
    public Armor CreateNewArmor(Armor armor)
    {
        Armor a = Instantiate(armor);
        a.name = armor.name;
        return a;
    }
    public Drop CreateNewDrop(Drop drop)
    {
        Drop d = Instantiate(drop);
        d.name = drop.name;
        return d;
    }
}