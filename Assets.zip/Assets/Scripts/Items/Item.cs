using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class Item : MonoBehaviour, IDragHandler,IEndDragHandler,IPointerDownHandler
{
    public SpriteRenderer pic;
    public Image inventoryPic;
    public Sprite none;
    public Weapon weapon;
    public Armor armor;
    public Drop drop;
    public Terrain terrain;
    public Location location;
    public Static staticObject;
    public bool player;
    public List<string> flavor;
    public int value;
    public int inventory;
    public Vector2 anchorPosition = new Vector2(0,0);    

    public void PickUp()
    {
        if(Return.NextEmptyInventorySlot()==null) CombatLog.instance.UpdateLog("Your Inventory is full. Throw something out");
        else
        {
            if (weapon != null)
            {
                CombatLog.instance.UpdateLog("You pick up the " + weapon.weaponName + " and put it in your backpack");
                GameManager.instance.AddToItem(weapon,Return.NextEmptyInventorySlot());
            }
            else if (armor != null)
            {
                CombatLog.instance.UpdateLog("You pick up the " + armor.armorName + " and put it in your backpack");
                GameManager.instance.AddToItem(armor, Return.NextEmptyInventorySlot());
            }
            else if (drop != null)
            {
                if (drop.type == DropType.Gold)
                {
                    CombatLog.instance.UpdateLog("You pick up " + value + " " + drop.dropName);
                    CombatLog.instance.UpdateLog("This will come in handy at the shop");
                    GameManager.instance.player.player.gold += value;
                }
                if (drop.type == DropType.Potion)
                {
                    CombatLog.instance.UpdateLog("You pick up the " + drop.dropName + " and put it in your backpack");
                    CombatLog.instance.UpdateLog("I wonder what it does?");
                    GameManager.instance.AddToItem(drop, Return.NextEmptyInventorySlot());
                }
                if (drop.type == DropType.Book)
                {
                    CombatLog.instance.UpdateLog("You pick up the " + drop.dropName + " and put it in your backpack");
                    CombatLog.instance.UpdateLog("I wonder what you can learn?");
                    GameManager.instance.AddToItem(drop, Return.NextEmptyInventorySlot());
                }
                if (drop.type == DropType.Key)
                {
                    CombatLog.instance.UpdateLog("You pick up the " + drop.dropName + " and put it in your backpack");
                    CombatLog.instance.UpdateLog("I bet it opens a door");
                    GameManager.instance.AddToItem(drop, Return.NextEmptyInventorySlot());
                }
            }
            Dungeon.instance.currentFloor.currentRoom.items.Remove(this);
            Destroy(gameObject);
            GameManager.instance.EndTurn();
        }        
    }    

    public bool NotEmpty() => weapon != null || armor != null || drop != null;

    public void Interact()
    {
        if (terrain.terrainName == ItemList.instance.shopKeeper.terrainName)
        {
            GameManager.instance.player.player.OpenShop();
        }
        else if (terrain.terrainName == ItemList.instance.fountain.terrainName)
        {
            if (!GetComponent<Fountain>().used)
            {
                GetComponent<Fountain>().Use();
                foreach (String s in terrain.triggerString)
                    CombatLog.instance.UpdateLog(s);
            }
        }
    }
            
    public void ChangeSprite()
    {
        pic.sprite = none;
        if (weapon != null) pic.sprite = weapon.sprite;
        else if (armor != null) pic.sprite = armor.sprite;
        else if (drop != null) pic.sprite = drop.sprite;
        else if (terrain != null) pic.sprite = terrain.sprite;
        else if (staticObject != null) pic.sprite = staticObject.sprite;
    }
    public void ChangeInventorySprite()
    {
        inventoryPic.sprite = none;
        if (weapon != null) inventoryPic.sprite = weapon.sprite;
        else if (armor != null) inventoryPic.sprite = armor.inventorySprite;
        else if (drop != null) inventoryPic.sprite = drop.sprite;
        else if (terrain != null)
        {
            inventoryPic.sprite = terrain.sprite;
        }
    }

    void IDragHandler.OnDrag(PointerEventData eventData)
    {
        if (inventory>0)
        {
            if (ValidItemToMove()) GetComponent<RectTransform>().anchoredPosition += eventData.delta / GameManager.instance.player.player.inventoryCanvas.scaleFactor;
        }
    }

    public bool ValidItemToMove()
    {
        if (weapon != null && weapon.weaponName != "Fist") return true;
        else if (armor != null) return true;
        else if (drop != null&& drop.dropName != "Sell") return true;
        return false;
    }

    void IEndDragHandler.OnEndDrag(PointerEventData eventData)
    {
        if (ValidItemToMove())
        {
            GameManager.instance.Overlap(this);
            transform.position = anchorPosition;          
        }              
    }

    void IPointerDownHandler.OnPointerDown(PointerEventData eventData)
    {
        GetComponent<RectTransform>().SetAsLastSibling();
    }
}
