using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Action : MonoBehaviour
{
    public static Action instance;
    public GameObject projectile;
    public List<GameObject> projectiles;
    public Sprite arrow;
    public Sprite knife;
    public Location l;
    public void Weapon(Agent attacker, Arm arm, Agent defender, Weapon weapon, Skill skill)
    {
        switch (skill.type)
        {
            case SkillType.Axe:
                Axe(attacker, arm,defender, weapon,skill);
                break;
            case SkillType.Bow:
                Bow(attacker, defender, weapon, skill);
                break;
            case SkillType.Dagger:
                Dagger(attacker, arm, defender, weapon, skill);
                break;
            case SkillType.Fist:
                Fist(attacker, arm, defender, weapon, skill);
                break;
            case SkillType.GreatAxe:
                GreatAxe(attacker, defender, weapon, skill);
                break;
            case SkillType.Shield:
                Shield(attacker, arm, defender, weapon, skill);
                break;
            case SkillType.Sword:
                Sword(attacker, arm, defender, weapon, skill);
                break;
        }
    }

    public bool Hit(Agent attacker, int coordination, Agent defender, Skill skill)
    {
        //Trying to hit with something stops the agent from casting
        attacker.StopCasting();
        //Announce what the agent is doing
        if (skill.cast) CombatLog.instance.UpdateLog((attacker == GameManager.instance.player) ? Return.AgentName(attacker, true, false) + skill.text[0] + Return.AgentName(defender, false, false) : Return.AgentName(attacker, true, false) + skill.text[1]);
        else CombatLog.instance.UpdateLog((attacker == GameManager.instance.player) ? Return.AgentName(attacker, true, false) + skill.text[0] + Return.AgentName(defender, false, false) : Return.AgentName(attacker, true, false) + skill.text[1] + Return.AgentName(defender, false, false));
        //Attempt to hit. If Fail, Return False
        int roll = Return.Int(1,101);
        roll += Return.SkillLevel(skill);
        roll += (coordination - skill.coordinationRequired) * 5;
        if (roll < skill.toHit)
        {
            CombatLog.instance.UpdateLog(Return.AgentName(attacker, true, false) + " " + Return.Grammar(attacker, "miss"));
            return false;
        }
        //Defence. If succeeds, return False. Agent should only get one chance to Block Or Parry 
        bool right = (defender.rightArm.coordination >= defender.leftArm.coordination) ? defender.rightArm : defender.leftArm;
        if (defender.decisions.canRightHandParry && right) if (Parry(defender.rightArm.coordination,       Return.ParryLevel(defender.rightArm.weapon),Return.ParryRequired(defender.rightArm.weapon), coordination,   Return.SkillLevel(skill), attacker, defender)) return false;        
        else if (defender.decisions.canLeftHandParry && !right) if (Parry(defender.leftArm.coordination,   Return.ParryLevel(defender.leftArm.weapon) ,Return.ParryRequired(defender.leftArm.weapon) ,  coordination,  Return.SkillLevel(skill), attacker, defender)) return false;
        else if (defender.decisions.canRightHandParry && !right) if (Parry(defender.rightArm.coordination, Return.ParryLevel(defender.rightArm.weapon),Return.ParryRequired(defender.rightArm.weapon), coordination,   Return.SkillLevel(skill), attacker, defender)) return false;
        else if (defender.decisions.canLeftHandParry && right) if (Parry(defender.leftArm.coordination,    Return.ParryLevel(defender.leftArm.weapon) ,Return.ParryRequired(defender.leftArm.weapon) ,  coordination,  Return.SkillLevel(skill), attacker, defender)) return false;
        else if (defender.decisions.canRightHandBlock && right) if (Block(defender.rightArm.coordination,  Return.BlockLevel(defender.rightArm.weapon),Return.BlockRequired(defender.rightArm.weapon), coordination,   Return.SkillLevel(skill), attacker, defender)) return false;
        else if (defender.decisions.canLeftHandBlock && !right) if (Block(defender.leftArm.coordination,   Return.BlockLevel(defender.leftArm.weapon) ,Return.BlockRequired(defender.leftArm.weapon) ,  coordination,  Return.SkillLevel(skill), attacker, defender)) return false;
        else if (defender.decisions.canRightHandBlock && !right) if (Block(defender.rightArm.coordination, Return.BlockLevel(defender.rightArm.weapon),Return.BlockRequired(defender.rightArm.weapon), coordination,   Return.SkillLevel(skill), attacker, defender)) return false;
        else if (defender.decisions.canLeftHandBlock && right) if (Block(defender.leftArm.coordination,    Return.BlockLevel(defender.leftArm.weapon) ,Return.BlockRequired(defender.leftArm.weapon) ,  coordination,  Return.SkillLevel(skill), attacker, defender)) return false;
        return true;
    }

    public bool Block(int defenceCoordination,int blockSkill, int toBlock, int attackCoordination,int attackSkill, Agent attacker, Agent defender)
    {
        int roll = Return.Int(1, 101);
        roll += blockSkill * 2 - attackSkill;
        roll += (defenceCoordination - attackCoordination) * 5;
        roll += (defender.decisions.guarding) ? 65 : 0;
        if (roll > toBlock)
        {
            CombatLog.instance.UpdateLog($"{Return.AgentName(attacker, true, false)} {Return.Grammar(attacker, "attack")} {Return.AgentName(defender, false, true)} attack!");
            return true;
        }
        return false;
    }

    public bool Parry(int defenceCoordination, int parrySkill, int toParry, int attackCoordination, int attackSkill, Agent attacker, Agent defender)
    {
        int roll = Return.Int(1, 101);
        roll += parrySkill *2 - attackSkill;
        roll += (defenceCoordination - attackCoordination) * 5;
        if (roll > toParry)
        {
            CombatLog.instance.UpdateLog($"{Return.AgentName(attacker, true, false)} { Return.Grammar(attacker, "parry")} {Return.AgentName(defender, false, true)} attack!");
            CombatLog.instance.UpdateLog($"{Return.AgentName(attacker, true, false)} {Return.Grammar(attacker,"attack")} {Return.AgentName(defender, false, false)}!");
            GameManager.instance.player.whoHitMeLast = attacker.agentName;
            Formulas.Target(defender, GameManager.instance.player.player.skills[2]).TakeDamage(Formulas.Damage(Return.Int(3, 7)), true);
            return true;
        }
        return false;
    }

    public void CastSkill(Agent attacker, Arm arm, Agent defender, Weapon weapon, Skill skill, string log, Sprite spriteToUse, string castText )
    {        
        attacker.StopCasting();        
        attacker.casting = true;
        attacker.castArm = arm;
        attacker.castDefender = defender;
        attacker.castWeapon = weapon;
        GameManager.instance.TurnOn(attacker.castObject);
        attacker.castObject.GetComponent<Text>().text = castText;
        attacker.castButton.GetComponent<Button>().GetComponent<Image>().sprite = spriteToUse;
        CombatLog.instance.UpdateLog(log);
        attacker.castSkill = skill;
    }
    public void GenericHit(Agent attacker, Agent defender, Weapon weapon, Skill skill, int raiseFamiliarity, int raiseSkill)
    {
        if (attacker == GameManager.instance.player && (raiseFamiliarity>0||raiseSkill>0))
        {
            attacker.RaiseFamiliarity(skill, weapon,raiseFamiliarity);
            attacker.RaiseSkill(skill, raiseSkill); 
        }
        defender.whoHitMeLast = attacker.agentName;
        Formulas.Target(defender, skill).TakeDamage(Formulas.Damage(attacker, skill), true);
    }
    public void GenericHit(Agent attacker, Agent defender, Weapon weapon, Skill skill)
    {
        if (attacker == GameManager.instance.player)
        {
            attacker.RaiseFamiliarity(skill, weapon,1);
            attacker.RaiseSkill(skill, 1);
        }
        defender.whoHitMeLast = attacker.agentName;
        Formulas.Target(defender, skill).TakeDamage(Formulas.Damage(attacker, skill), true);
    }

    private void Axe(Agent attacker, Arm arm, Agent defender, Weapon weapon, Skill skill)
    {
        if (skill.actionName == "Break Shield")
        {
            if (defender.rightArm.weapon.availableActions[0].type == SkillType.Shield|| defender.leftArm.weapon.availableActions[0].type == SkillType.Shield)
            {
                if (attacker.casting)
                {
                    if (Hit(attacker, arm.coordination, defender, skill))
                    {
                        //Figure out if defender has a shield and break it if they do
                        if (defender.rightArm.weapon.availableActions[0].type == SkillType.Shield)
                        {
                            attacker.RaiseSkill(skill, 2);
                            CombatLog.instance.UpdateLog(Return.AgentName(attacker, true, false) + " " + Return.Grammar(attacker, "slam") + Return.AgentName(defender, false, true) + " shield rendering it useless");
                            defender.rightArm.Equip(ItemList.instance.rightFist);
                        }
                        else if (defender.leftArm.weapon.availableActions[0].type == SkillType.Shield)
                        {
                            CombatLog.instance.UpdateLog(Return.AgentName(attacker, true, false) + " " + Return.Grammar(attacker, "slam") + Return.AgentName(defender, false, true) + " shield rendering it useless");
                            defender.leftArm.Equip(ItemList.instance.leftFist);
                        }
                    }
                }
                else CastSkill(attacker, arm, defender, weapon, skill, (GameManager.instance.player) ? Return.AgentName(attacker, true, false) + skill.text[2] : Return.AgentName(attacker, true, false) + skill.text[3], GameManager.instance.breakShield, "Break Shield");
            }
            else CombatLog.instance.UpdateLog(Return.AgentName(defender, true, false) + " " + Return.Grammar(attacker, "don't") + " have a shield!");            
        }
        else if (skill.actionName == "Rend Armor")
        {
            //Figure out What body part it hits
            Body b = Return.TargetBodyArmor(defender);
            if (b != null)
            {
                if (attacker.casting)
                {
                    if (Hit(attacker, arm.coordination, defender, skill))
                    {
                        attacker.RaiseSkill(skill, 2);
                        int damage = b.armor.hp;
                        CombatLog.instance.UpdateLog(Return.AgentName(attacker, true, false) + " " +Return.Grammar(attacker,"rend") +" "+ Return.AgentName(defender, false, true) + " " + Return.BodyName(b) + " armor rendering it useless");
                        b.TakeDamage(damage,false);
                    }
                }
                else CastSkill(attacker, arm, defender, weapon, skill, (GameManager.instance.player) ? Return.AgentName(attacker, true, false) + skill.text[2] : Return.AgentName(attacker, true, false) + skill.text[3], GameManager.instance.rendArmor, "Rend Armor");
            }                
            else CombatLog.instance.UpdateLog(Return.AgentName(defender, true, false) + " "+ Return.Grammar(attacker, "don't")+ " have armor!");
            
        }
        else
        {
            if (Hit(attacker, arm.coordination, defender, skill)) GenericHit(attacker, defender, weapon, skill);
        }        
    }

    private void Bow(Agent attacker, Agent defender, Weapon weapon, Skill skill)
    {
        if (skill.actionName == "Shoot")
        {
            Projectile(arrow, attacker, defender);
            if (Hit(attacker, (attacker.rightArm.coordination + attacker.leftArm.coordination) / 2, defender, skill))
            {                
                GenericHit(attacker, defender, weapon, skill);
            }
        }
        else if (skill.actionName == "Careful Shot")
        {
            if (attacker.casting)
            {
                Projectile(arrow, attacker, defender);
                if (Hit(attacker, (attacker.rightArm.coordination + attacker.leftArm.coordination) / 2, defender, skill))
                {
                    GenericHit(attacker, defender, weapon, skill);
                }
            }
            else CastSkill(attacker, attacker.rightArm, defender, weapon, skill, (GameManager.instance.player) ? Return.AgentName(attacker, true, false) + skill.text[2] : Return.AgentName(attacker, true, false) + skill.text[3], GameManager.instance.carefulShot, "Careful Shot");
        }
        else if (skill.actionName == "Rapid Fire")
        {
            CombatLog.instance.UpdateLog(Return.AgentName(attacker, true, false) + Return.Grammar(attacker, " fire ")  + "rapidly at "+ Return.AgentName(defender, false, false));
            Projectile(arrow, attacker, defender);
            if (Hit(attacker, (attacker.rightArm.coordination + attacker.leftArm.coordination) / 2, defender, skill)) 
            {
                GenericHit(attacker, defender, weapon, skill);
            }
            if (defender.head.status!=Status.Destroyed && defender.body.status != Status.Destroyed)
            {
                Projectile(arrow, attacker, defender);
                if (Hit(attacker, (attacker.rightArm.coordination + attacker.leftArm.coordination) / 2, defender, skill))
                {
                    GenericHit(attacker, defender, weapon, skill,0,0);
                }
            }            
        }
        else if (skill.actionName.Contains("Double Shot"))
        {
            if (attacker.casting)
            {
                List<Agent> targets = Return.TargetsInRange(attacker, skill.range);
                Agent secondary = null;
                foreach(Agent a in targets)
                {
                    if (a != defender && a != GameManager.instance.player) secondary = a;
                }
                Projectile(arrow, attacker, defender);
                if (Hit(attacker, (attacker.rightArm.coordination + attacker.leftArm.coordination) / 2, defender, skill))
                {
                    Projectile(arrow, defender, secondary);
                    CombatLog.instance.UpdateLog($"Your shot ricochets off of {Return.AgentName(defender, false, false)} and heads toward {Return.AgentName(secondary, false, false)}");
                    GenericHit(attacker, defender, weapon, skill);                    
                    defender = secondary;
                    if (Hit(attacker, (attacker.rightArm.coordination + attacker.leftArm.coordination) / 2, defender, skill))
                    {
                        GenericHit(attacker, defender, weapon, skill,0,0);
                    }
                }
            }
            else CastSkill(attacker, attacker.rightArm, defender, weapon, skill, (GameManager.instance.player) ? Return.AgentName(attacker, true, false) + skill.text[2] : Return.AgentName(attacker, true, false) + skill.text[3], GameManager.instance.doubleShot, "Double Shot");
        }
        else if (skill.actionName.Contains("Knockdown"))
        {
            if (attacker.casting)
            {
                Projectile(arrow, attacker, defender);
                if (Hit(attacker, (attacker.rightArm.coordination + attacker.leftArm.coordination) / 2, defender, skill))
                {
                    GenericHit(attacker, defender, weapon, skill);
                    if (defender.head.status != Status.Destroyed && defender.body.status != Status.Destroyed)
                    {
                        defender.knockedDown = (skill.magnitude - defender.resilience > 0) ? skill.magnitude - defender.resilience : 0;
                        if (defender.knockedDown > 0) CombatLog.instance.UpdateLog(Return.AgentName(defender, true, false) + " is knocked down!");
                        else CombatLog.instance.UpdateLog(Return.AgentName(defender, true, false) + " cannot be knocked down by a knockdown shot! They are too resilient!");
                    }
                }
            }
            else CastSkill(attacker, attacker.rightArm, defender, weapon, skill, (GameManager.instance.player) ? Return.AgentName(attacker, true, false) + skill.text[2] : Return.AgentName(attacker, true, false) + skill.text[3], GameManager.instance.knockdown, "Knockdown Shot");
        }
    }

    private void Dagger(Agent attacker, Arm arm, Agent defender, Weapon weapon, Skill skill)
    {
        if (skill.actionName == "Stab")
        {
            if (Hit(attacker, arm.coordination, defender, skill))
            {
                GenericHit(attacker, defender, weapon, skill);
            }
        }
        else if (skill.actionName == "Throw")
        {
            if (Hit(attacker, arm.coordination, defender, skill))
            {
                Projectile(knife, attacker, defender);
                GenericHit(attacker, defender, weapon, skill);
            }
        }
    }

    private void Fist(Agent attacker, Arm arm, Agent defender, Weapon weapon, Skill skill)
    {
        if (skill.actionName.Contains("Guard"))
        {
            attacker.decisions.guarding = true;
            CombatLog.instance.UpdateLog((attacker == GameManager.instance.player) ?skill.text[0]:Return.AgentName(attacker,true,false)+skill.text[1]);
        }
        else if (skill.actionName == "Haymaker")
        {
            if (attacker.casting)
            {
                if (Hit(attacker, arm.coordination, defender, skill))
                {
                    GenericHit(attacker, defender, weapon, skill);
                    if (defender.head.status != Status.Destroyed && defender.body.status != Status.Destroyed)
                    {
                        CombatLog.instance.UpdateLog(Return.AgentName(defender, true, false) + " is knocked back!");
                        l = Return.OppositeTile(defender, attacker);
                        if (l.cost == 99)
                        {
                            CombatLog.instance.UpdateLog(Return.AgentName(defender, true, false) + " hits the wall!");
                        }
                        else if (l.cost == 100)
                        {
                            CombatLog.instance.UpdateLog(Return.AgentName(defender, true, false) + " hits a door!");
                        }
                        else if (l.occupiedBy != null)
                        {
                            CombatLog.instance.UpdateLog(Return.AgentName(defender, true, false) + $" flies into {Return.AgentName(l.occupiedBy, true, false)}!");
                        }
                        else
                        {
                            defender.moved = true;
                            defender.location = l;
                            defender.transform.position = new Vector2(l.x, l.y);
                            GameManager.instance.FindLocation();
                        }
                    }
                }
            }
            else CastSkill(attacker, arm, defender, weapon, skill, (GameManager.instance.player) ? Return.AgentName(attacker, true, false) + skill.text[2] : Return.AgentName(attacker, true, false) + skill.text[3], GameManager.instance.haymaker, "Haymaker");
            
        }
        else if (skill.actionName == "Uppercut")
        {
            if (attacker.casting)
            {
                if (Hit(attacker, arm.coordination, defender, skill))
                {
                    GenericHit(attacker, defender, weapon, skill);
                    if (defender.head.status != Status.Destroyed && defender.body.status != Status.Destroyed)
                    {
                        defender.knockedDown = (skill.magnitude - defender.resilience > 0) ? skill.magnitude - defender.resilience : 0;
                        if (defender.knockedDown > 0) CombatLog.instance.UpdateLog(Return.AgentName(defender, true, false) + " is knocked down!");
                        else CombatLog.instance.UpdateLog(Return.AgentName(defender, true, false) + $" cannot be knocked down by an uppercut! {Return.AgentName(defender, true, false)} {Return.Grammar(defender, "is")} too resilient!");
                    }
                }
            }
            else CastSkill(attacker, arm, defender, weapon, skill, (GameManager.instance.player) ? Return.AgentName(attacker, true, false) + skill.text[2] : Return.AgentName(attacker, true, false) + skill.text[3], GameManager.instance.uppercut, "Uppercut");
        }
        else if (skill.actionName.Contains("Punch"))
        {
            if (Hit(attacker, arm.coordination, defender, skill))
            {
                GenericHit(attacker, defender, weapon, skill);
            }
        }
    }

    private void GreatAxe(Agent attacker, Agent defender, Weapon weapon, Skill skill)
    {
        if (Hit(attacker, (attacker.rightArm.coordination + attacker.leftArm.coordination)/2, defender, skill))
        {

        }
    }

    private void Shield(Agent attacker, Arm arm, Agent defender, Weapon weapon, Skill skill)
    {
        if (skill.actionName.Contains("Guard"))
        {
            attacker.decisions.guarding = true;
            CombatLog.instance.UpdateLog((attacker == GameManager.instance.player) ? skill.text[0] : Return.AgentName(attacker, true, false) + skill.text[1]);
        }
        else
        {
            if (Hit(attacker, arm.coordination, defender, skill))
            {
                GenericHit(attacker, defender, weapon, skill);
            }
        }        
    }

    private void Sword(Agent attacker, Arm arm, Agent defender, Weapon weapon, Skill skill)
    {
        if (skill.actionName.Contains("Guard"))
        {
            attacker.decisions.guarding = true;
            CombatLog.instance.UpdateLog((attacker == GameManager.instance.player) ? skill.text[0] : Return.AgentName(attacker, true, false) + skill.text[1]);
        }
        else if (skill.actionName.Contains("Cut")|| skill.actionName.Contains("Stab"))
        {
            GenericHit(attacker, defender, weapon, skill);
        }
        else if (skill.actionName.Contains("Cleave") )
        {
            List<Agent> targets = Return.TargetsInRange(attacker, skill.range);
            Agent secondary = null;
            foreach (Agent a in targets)
            {
                if (a != defender && a != GameManager.instance.player) secondary = a;
            }
            CombatLog.instance.UpdateLog($"You cleave, striking {Return.AgentName(defender, false, false)} and {Return.AgentName(secondary, false, false)}!");
            if (Hit(attacker, arm.coordination, defender, skill))
            {
                
                GenericHit(attacker, defender, weapon, skill);                
            }
            defender = secondary;
            if (Hit(attacker, (attacker.rightArm.coordination + attacker.leftArm.coordination) / 2, defender, skill))
            {
                GenericHit(attacker, defender, weapon, skill, 0, 0);
            }
        }
    }

    public void Spell(Agent attacker, Agent defender, Skill skill)
    {
        attacker.StopCasting();
        GameManager.instance.TurnOn(attacker.spell.castObject);
        if (skill.skillName.Contains("Flame"))
        {
            bool alreadyCast = false;
            foreach (Skill checkSkill in attacker.spell.spell) if (checkSkill.skillName == skill.skillName) alreadyCast = true;
            if (!alreadyCast)
            {
                string a = (skill.skillName.Contains("Head")) ? skill.text[1] : (skill.skillName.Contains("Left")) ? skill.text[3] : skill.text[5];
                CombatLog.instance.UpdateLog(skill.text[attacker.spell.spell.Count * 2] + Return.AgentName(attacker, true, false) + a);
                attacker.spell.spell.Add(skill);
            }
            attacker.spell.castButton.GetComponent<Button>().GetComponent<Image>().sprite = attacker.spell.flameSprite[attacker.spell.spell.Count-1];
        }
    }    

    public void LegAttack(Agent source, Agent a, Skill loadSkill)
    {
        
    }

    public void Projectile(Sprite sprite,Agent attacker, Agent target)
    {
        for (int i = 0; i < 5; i++)
        {
            if (!projectiles[i].activeSelf)
            {
                projectiles[i].SetActive(true);
                projectiles[i].transform.position = attacker.transform.position;
                projectiles[i].GetComponent<Projectile>().target = target;
                projectiles[i].GetComponent<SpriteRenderer>().sprite = sprite;
                break;
            }            
        }        
    }

    private void Awake()
    {
        instance = this;
        for (int i = 0; i < 5; i++)
        {
            GameObject x = Instantiate(projectile);
            x.name = projectile.name + $" {i+1}";
            projectiles.Add(x);
            x.SetActive(false);
        }        
    }
}
