using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using UnityEngine.UI;
using System;

public class Decisions : MonoBehaviour
{
    public Agent source;
    public bool guarding;
    public bool canRightHandBlock;
    public bool canRightHandParry;
    public bool canLeftHandBlock;
    public bool canLeftHandParry;
    public List<Skill> rightHandSkills;
    public List<Skill> leftHandSkills;
    public List<Skill> legSkills;
    public List<Skill> headSkills;
    public List<string> rightHandSkillNames;
    public List<string> leftHandSkillNames;
    public List<string> legSkillNames;
    public List<string> headSkillNames;
    public int rightValue;
    public int leftValue;
    public int legsValue;
    public int headValue;
    public List<Skill> actions ;
    public Skill skillToUse ;
    public List<Agent> targetsInRange;
    public void UpdateAvailableDecisions()
    {
        canRightHandBlock=false;
        canRightHandParry=false;
        canLeftHandBlock =false;
        canLeftHandParry =false;
        rightHandSkills.Clear();
        leftHandSkills.Clear();
        legSkills.Clear();
        headSkills.Clear();
        AddHeadActions();
        if (source.rightArm.status != Status.Destroyed)
        {
            foreach (Skill r in source.rightArm.weapon.availableActions)
            {
                foreach (Skill s in source.head.knownActions)
                {
                    if (s.actionName == r.actionName)
                    {
                        if (source.GetComponent<SpellCasting>())
                        {
                            bool bad = false;
                            foreach (Skill skill in source.GetComponent<SpellCasting>().spell)
                            {
                                if (skill.skillName == s.skillName) bad = true;
                            }
                            if (!bad)
                            {
                                if (s.range == 0) rightHandSkills.Add(s);
                                else if (FindTargetsInRange(source, s)) rightHandSkills.Add(s);
                                break;

                            }
                            else break;
                        }
                        else
                        {
                            if (s.range == 0) rightHandSkills.Add(s);
                            else if (FindTargetsInRange(source, s)) rightHandSkills.Add(s);
                            break;
                        }                        
                    }
                }
            }
        }
        if (source.leftArm.status != Status.Destroyed)
        {
            foreach (Skill l in source.leftArm.weapon.availableActions)
            {
                foreach (Skill s in source.head.knownActions)
                {
                    if (s.actionName == l.actionName)
                    {
                        if (source.GetComponent<SpellCasting>())
                        {
                            bool bad = false;
                            foreach (Skill skill in source.GetComponent<SpellCasting>().spell)
                            {
                                if (skill.skillName == l.skillName) bad = true;
                            }
                            if (!bad)
                            {
                                if (l.range == 0) leftHandSkills.Add(l);
                                else if (FindTargetsInRange(source, l)) leftHandSkills.Add(l);
                                break;

                            }
                            else break;
                        }
                        else
                        {
                            if (l.range == 0) leftHandSkills.Add(l);
                            else if (FindTargetsInRange(source, l)) leftHandSkills.Add(l);
                            break;
                        }
                    }
                }
            }
        }
        if (source.legs.status != Status.Destroyed)
        {
            foreach (Skill l in source.legs.availableActions)
            {
                foreach (Skill s in source.head.knownActions)
                {
                    if (s.actionName == l.actionName)
                    {
                        if (source.GetComponent<SpellCasting>())
                        {
                            bool bad = false;
                            foreach (Skill skill in source.GetComponent<SpellCasting>().spell)
                            {
                                if (skill.skillName == s.skillName) bad = true;
                            }
                            if (!bad)
                            {
                                if (s.range == 0) legSkills.Add(s);
                                else if (FindTargetsInRange(source, s)) legSkills.Add(s);
                                break;

                            }
                            else break;
                        }
                        else
                        {
                            if (s.range == 0) legSkills.Add(s);
                            else if (FindTargetsInRange(source, s)) legSkills.Add(s);
                            break;
                        }
                    }
                }
            }
        }
        if (source.head.headActions.Count != 0)
        {
            foreach (Skill s in source.head.headActions)
            {
                if (source.GetComponent<SpellCasting>())
                {
                    bool bad = false;
                    foreach (Skill skill in source.GetComponent<SpellCasting>().spell)
                    {
                        if (skill.skillName == s.skillName) bad = true;
                    }
                    if (!bad)
                    {
                        if (s.range == 0) headSkills.Add(s);
                        else if (s.range == 99)
                        {
                            List<Agent> t = Return.TargetsInRange(source, 1);
                            if (t.Count == 1 && t[0].GetComponent<Enemy>()) headSkills.Add(s);
                        }
                        else if (FindTargetsInRange(source, s)) headSkills.Add(s);
                    }
                    else break;
                }
                else
                {
                    if (s.range == 0) headSkills.Add(s);
                    else if (s.range == 99)
                    {
                        List<Agent> t = Return.TargetsInRange(source, 1);
                        if (t.Count == 1 && t[0].GetComponent<Enemy>()) headSkills.Add(s);
                    }
                    else if (FindTargetsInRange(source, s)) headSkills.Add(s);
                }                
            }
        }        
        if (headSkills.Count == 0) headSkills.Add(GameManager.instance.noTarget);
        if (rightHandSkills.Count == 0) rightHandSkills.Add(GameManager.instance.noTarget);
        if (leftHandSkills.Count == 0) leftHandSkills.Add(GameManager.instance.noTarget);        
        if (source.player != null)
        {
            leftHandSkillNames.Clear();
            rightHandSkillNames.Clear();
            legSkillNames.Clear();
            headSkillNames.Clear();
            if (source.rightArm.status != Status.Destroyed)
            {
                for (int i = 0; i < rightHandSkills.Count; i++) 
                {
                    string x = (rightHandSkills.Count >1)?(i + 1).ToString():"";
                    rightHandSkillNames.Add(String.Format("{0,-15}{1,-10}",rightHandSkills[i].actionName, x));
                    if (rightHandSkills[i].actionName == "Block") canRightHandBlock = true;
                    if (rightHandSkills[i].actionName == "Parry") canRightHandParry = true;
                }                    
            }
            else rightHandSkillNames.Add("Disabled");
            if (source.leftArm.status != Status.Destroyed)
            {
                for (int i = 0; i < leftHandSkills.Count; i++)
                {
                    if (leftHandSkills[i].actionName.Contains("No Target") && source.rightArm.weapon.handed == Handed.Two) leftHandSkillNames.Add("Two Handed");
                    else
                    {
                        string x = (leftHandSkills.Count > 1) ? (i + 1).ToString() : "";
                        leftHandSkillNames.Add($"{leftHandSkills[i].actionName} {x}");
                        if (leftHandSkills[i].actionName == "Block") canRightHandBlock = true;
                        if (leftHandSkills[i].actionName == "Parry") canRightHandParry = true;
                    }
                }
            }
            else leftHandSkillNames.Add("Disabled");
            if (source.legs.status != Status.Destroyed)
            {
                foreach (Skill s in legSkills)
                {
                    legSkillNames.Add(s.actionName);
                }
            }
            else legSkillNames.Add("Disabled");
            foreach (Skill s in headSkills)
            {
                headSkillNames.Add(s.actionName);
            }
            
            if (CompareTag(PlayerInput.instance.skillDropDowns[0], leftHandSkillNames))
            {
                PlayerInput.instance.skillDropDowns[0].ClearOptions();
                PlayerInput.instance.skillDropDowns[0].AddOptions(leftHandSkillNames);
                PlayerInput.instance.skillDropDowns[0].RefreshShownValue();
                PlayerInput.instance.skillDropDowns[0].Show();
                PlayerInput.instance.skillDropDowns[0].Hide();
            }
            if (CompareTag(PlayerInput.instance.skillDropDowns[1], rightHandSkillNames))
            {
                PlayerInput.instance.skillDropDowns[1].ClearOptions();
                PlayerInput.instance.skillDropDowns[1].AddOptions(rightHandSkillNames);
                PlayerInput.instance.skillDropDowns[1].RefreshShownValue();
                PlayerInput.instance.skillDropDowns[1].Show();
                PlayerInput.instance.skillDropDowns[1].Hide();
            }
            if (CompareTag(PlayerInput.instance.skillDropDowns[2], legSkillNames))
            {
                PlayerInput.instance.skillDropDowns[2].ClearOptions();
                PlayerInput.instance.skillDropDowns[2].AddOptions(legSkillNames);
                PlayerInput.instance.skillDropDowns[2].RefreshShownValue();
                PlayerInput.instance.skillDropDowns[2].Show();
                PlayerInput.instance.skillDropDowns[2].Hide();
            }
            if (CompareTag(PlayerInput.instance.skillDropDowns[3], headSkillNames))
            {
                PlayerInput.instance.skillDropDowns[3].ClearOptions();
                PlayerInput.instance.skillDropDowns[3].AddOptions(headSkillNames);
                PlayerInput.instance.skillDropDowns[3].RefreshShownValue();
                PlayerInput.instance.skillDropDowns[3].Show();
                PlayerInput.instance.skillDropDowns[3].Hide();
            }
        }        
        //What item each dropdown is on
        rightValue = (rightValue >= rightHandSkills.Count) ? 0: rightValue;
        leftValue = (leftValue >= leftHandSkills.Count) ? 0 : leftValue;
        legsValue = (legsValue >= legSkills.Count) ?0 : legsValue;
        headValue = (headValue >= headSkills.Count) ? 0 : headValue;
    }

    private void AddHeadActions()
    {        
        source.head.knownActions.Clear();
        List<Skill> rightHand = GetSkills(source.rightArm.weapon.availableActions, source.rightArm);
        List<Skill> leftHand = GetSkills(source.leftArm.weapon.availableActions, source.leftArm);
        List<Skill> legs = GetSkills(source.legs.availableActions, source.legs);
        foreach (Skill s in rightHand) GameManager.instance.SkillAdd(s, source);
        foreach (Skill s in leftHand) GameManager.instance.SkillAdd(s, source);
        foreach (Skill s in legs) GameManager.instance.SkillAdd(s, source);
    }

    public List<Skill> GetSkills(List<Skill> availableActions,Arm arm)
    {
        List<Skill> newList = new List<Skill> { };
        foreach (Skill s in availableActions)
        {
            if (s.type == SkillType.Axe) 
            { 
                if (source.axeFamiliarity >= s.familiarityRequired && arm.coordination >= s.coordinationRequired &&!s.passive && Return.ConditionCheck(s,source)) newList.Add(s);
            }
            else if (s.type == SkillType.Bow)
            {
                if (source.bowFamiliarity >= s.familiarityRequired && arm.coordination >= s.coordinationRequired && !s.passive && Return.ConditionCheck(s, source)) newList.Add(s);
            }
            else if (s.type == SkillType.Spell) 
            { 
                if (source.head.intelligence >= s.familiarityRequired && arm.coordination >= s.coordinationRequired && !s.passive && Return.ConditionCheck(s, source)) newList.Add(s);
            }
            else if (s.type == SkillType.Dagger)
            { 
                if (source.daggerFamiliarity >= s.familiarityRequired && arm.coordination >= s.coordinationRequired && !s.passive && Return.ConditionCheck(s, source)) newList.Add(s);
            }
            else if (s.type == SkillType.Fist)
            {
                if (source.fistFamiliarity >= s.familiarityRequired && arm.coordination >= s.coordinationRequired && !s.passive && Return.ConditionCheck(s, source))
                {
                    if ((source.player != null && s.playerOnly) || !s.playerOnly) newList.Add(s);
                }                       
            }
            else if (s.type == SkillType.Shield)
            {
                if (source.shieldFamiliarity >= s.familiarityRequired && arm.coordination >= s.coordinationRequired && !s.passive && Return.ConditionCheck(s, source)) newList.Add(s);
            }                
            else if (s.type == SkillType.Sword)
            {
                if (source.swordFamiliarity >= s.familiarityRequired && arm.coordination >= s.coordinationRequired && !s.passive && Return.ConditionCheck(s, source)) newList.Add(s);
            }               
            else if (s.type == SkillType.GreatAxe)
            {
                if (source.greatAxeFamiliarity >= s.familiarityRequired && arm.coordination >= s.coordinationRequired && !s.passive && Return.ConditionCheck(s, source)) newList.Add(s);
            }             
            else if (s.type == SkillType.GreatSword)
            {
                if (source.greatSwordFamiliarity >= s.familiarityRequired && arm.coordination >= s.coordinationRequired && !s.passive && Return.ConditionCheck(s, source)) newList.Add(s);
            }                
        }
        return newList;
    }
    public List<Skill> GetSkills(List<Skill> availableActions, Legs leg)
    {
        List<Skill> newList = new List<Skill> { };
        foreach (Skill s in availableActions)
        {
            if (source.legFamiliarity >= s.familiarityRequired) newList.Add(s);
        }
        return newList;
    }

    public bool FindTargetsInRange(Agent a, Skill s)
    {
        targetsInRange = Return.TargetsInRange(a, s.range);
        return targetsInRange.Count > 0;
    }

    private bool CompareTag(Dropdown dropDown, List<string> s)
    {
        if (dropDown.options.Count != s.Count) return true;
        for (int i = 0; i < dropDown.options.Count; i++) if (dropDown.options[i].text != s[i]) return true;
        return false;
    }

    public void ActionSelect(Skill skill, Arm arm, Weapon weapon)
    {
        if (skill.type == SkillType.Spell && source.spell.spell.Count > 0)
        {
            Action.instance.Spell(source, source.target, skill);
            GameManager.instance.EndTurn();
        }
        else
        {
            FindTargetsInRange(source, skill);
            if (targetsInRange.Count == 1 || skill.actionName.Contains("Guard"))
            {
                source.target = targetsInRange[0];
                if (skill.type == SkillType.Spell) Action.instance.Spell(source, source.target, skill);
                else Action.instance.Weapon(source, arm, source.target, weapon, skill);
                if (!GameManager.instance.player.moved)
                {
                    GameManager.instance.EndTurn();
                }
            }
            else if (targetsInRange.Count > 1)
            {
                if (source.player != null)
                {
                    CombatLog.instance.Clean();
                    PlayerInput.instance.loadSkill = skill;
                    PlayerInput.instance.loadArm = arm;
                    PlayerInput.instance.loadWeapon = weapon;
                    CombatLog.instance.UpdateLog("Please select a target");
                    List<Agent> t = new List<Agent> { };
                    foreach (Agent a in Dungeon.instance.currentFloor.currentRoom.agentList) if (a != source) t.Add(a);
                    for (int i = 0; i < t.Count; i++)
                    {
                        CombatLog.instance.UpdateLog($"[{i+1}] {Return.AgentName(t[i], true, false)}");
                    }
                    PlayerInput.instance.potentialTargets = t;
                }
            }
        }
    }
    public void ActionSelect(Skill skill)
    {
        if (skill.type == SkillType.Spell && source.spell.spell.Count > 0)
        {
            Action.instance.Spell(source, source.target, skill);
            GameManager.instance.EndTurn();
        }
        else
        {
            if (skill.actionName == "Look")
            {
                CombatLog.instance.Clean();
                CombatLog.instance.UpdateLog("What would you like to examine?");
                PlayerInput.instance.looking = true;
            }
            if (skill.type == SkillType.Spell)
            {
                if (targetsInRange.Count == 1)
                {
                    source.target = targetsInRange[0];
                    Action.instance.Spell(source, source.target, skill);
                    if (!GameManager.instance.player.moved)
                    {
                        GameManager.instance.EndTurn();
                    }
                }
                else if (targetsInRange.Count > 1)
                {
                    if (source.player != null)
                    {
                        PlayerInput.instance.loadSkill = skill;
                        PlayerInput.instance.loadHead = true;
                        CombatLog.instance.UpdateLog("Please select a target");
                    }
                }
            }
        }
    }

    public void RightHandPress()
    {
        source.player.lastArmUsed = (source.rightArm.weapon.handed == Handed.Two)? ArmUse.Both: ArmUse.Right;
        if (GameManager.instance.player.rightArm.status != Status.Destroyed) ActionSelect(rightHandSkills[rightValue], source.rightArm, source.rightArm.weapon);
        else CombatLog.instance.UpdateLog("Your right arm is disabled!");
    }
    public void LeftHandPress()
    {
        source.player.lastArmUsed = ArmUse.Left;
        if (GameManager.instance.player.leftArm.status != Status.Destroyed) ActionSelect(leftHandSkills[leftValue], source.leftArm, source.leftArm.weapon);
        else CombatLog.instance.UpdateLog("Your left arm is disabled!");
    }
    public void LegPress()
    {
        source.player.lastArmUsed = ArmUse.None;
        if (GameManager.instance.player.legs.status != Status.Destroyed) ActionSelect(legSkills[legsValue]);
    }
    public void HeadPress()
    {
        source.player.lastArmUsed = ArmUse.None;
        ActionSelect(headSkills[headValue]);
    }
    public void Enemy()
    {
        skillToUse = null;
        actions.Clear();
        //Figure out what you CAN do
        foreach (Skill r in rightHandSkills) if (r != GameManager.instance.noTarget) actions.Add(r);
        foreach (Skill l in leftHandSkills) if (l != GameManager.instance.noTarget )actions.Add(l);
        int sumOfPriorities = 0;
        int rightHand = 0;
        Return.SortPriority(actions);
        //Figure out what your action will be
        foreach (Skill s in actions) sumOfPriorities += s.priority;
        foreach (Skill s in rightHandSkills) rightHand += s.priority;
        int priorityNumber = Return.Int(0, sumOfPriorities);
        int skillChosen = 0;
        bool right= false;
        foreach (Skill s in actions)
        {
            skillChosen += s.priority;
            if (skillChosen > priorityNumber)
            {
                skillToUse = s;
                if (skillChosen > rightHand) right = true;
                break;
            }
        }
        if (skillToUse == null) source.legs.MoveTowards(source.target.location);
        else
        {
            if (right) ActionSelect(skillToUse,source.rightArm,source.rightArm.weapon);
            else ActionSelect(skillToUse, source.leftArm, source.leftArm.weapon);
        }
    }
}