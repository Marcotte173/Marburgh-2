using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Library : MonoBehaviour
{
    public static Library instance;
    public Sprite libraryFloor;
    public Sprite libraryWall;
    public List<Sprite> booksNorth;
    public List<Sprite> booksSouth;
    public List<Sprite> booksEast;
    public List<Sprite> booksWest;
    public List<Sprite> pedastel;
    public Static bookshelf;
    private void Awake()
    {
        instance = this;
    }
}
