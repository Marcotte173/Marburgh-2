﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;

public class PlayerInput : MonoBehaviour
{
    public bool combatOn;
    public static PlayerInput instance;
    public Agent source;
    public List<Dropdown> skillDropDowns = new List<Dropdown> { };
    public Arm loadArm;
    public Weapon loadWeapon;
    public Skill loadSkill;
    public bool loadHead;
    public bool loadLegs;
    public Location location;
    public bool looking;
    Vector3 mousePos = new Vector3(0, 0, 0);
    bool rightHandSelect;
    public List<Agent> potentialTargets;

    private void Awake()
    {
        instance = this;
        rightHandSelect = true;
    }

    public void MakeSkillDropDowns()
    {
        skillDropDowns.Clear();
        skillDropDowns.Add(source.player.dropDownList[0]);
        skillDropDowns.Add(source.player.dropDownList[1]);
        skillDropDowns.Add(source.player.dropDownList[2]);
        skillDropDowns.Add(source.player.dropDownList[3]);
        for (int i = 0; i < 3; i++)
        {
            skillDropDowns[i].ClearOptions();
        }
        skillDropDowns[0].onValueChanged.AddListener(delegate
        {
            LeftChange(skillDropDowns[0]);
        });
        skillDropDowns[1].onValueChanged.AddListener(delegate
        {
            RightChange(skillDropDowns[1]);
        });
        skillDropDowns[2].onValueChanged.AddListener(delegate
        {
            LegChange(skillDropDowns[2]);
        });
        skillDropDowns[3].onValueChanged.AddListener(delegate
        {
            HeadChange(skillDropDowns[3]);
        });
    }

    public void RightChange(Dropdown change)
    {
        source.decisions.rightValue = change.value;
    }
    public void LeftChange(Dropdown change)
    {
        source.decisions.leftValue = change.value;
    }
    public void LegChange(Dropdown change)
    {
        source.decisions.legsValue = change.value;
    }
    public void HeadChange(Dropdown change)
    {
        source.decisions.headValue = change.value;
    }

    private void Update()
    {
        if (Input.GetKeyUp(KeyCode.Escape) && !GameManager.instance.title.activeSelf && !GameManager.instance.playerSetup.activeSelf)
        {
            if(source.player.box .gameObject.activeSelf|| source.player.box2.gameObject.activeSelf || source.player.box3.gameObject.activeSelf) source.player.CloseShop();
            else GameManager.instance.Options();            
        }
        if (combatOn)
        {            
            if (source.knockedDown>0)
            {
                if (Input.GetKeyUp(KeyCode.Space))
                {
                    CombatLog.instance.Clean();
                    CombatLog.instance.UpdateLog($"{Return.AgentName(source, true, false)} get up");
                    source.knockedDown--;
                    GameManager.instance.EndTurn();
                }
                if (Input.anyKeyDown)
                {
                    CombatLog.instance.UpdateLog($"{Return.AgentName(source,true,false)} have been knocked down. Press Space bar to get back up");
                }                
            }
            else
            {
                if (!GameManager.instance.player.moved)
                {
                    if (Input.GetKeyUp(KeyCode.LeftAlt))
                    {
                        source.player.dropDownList[1].Show();
                        rightHandSelect = true;
                    }
                    if (Input.GetKeyUp(KeyCode.LeftControl))                        
                    {
                        source.player.dropDownList[0].Show();
                        rightHandSelect = false;
                    }
                    if(potentialTargets.Count >0)
                    {
                        if (Input.GetKeyUp(KeyCode.Alpha1)) AttackTarget(potentialTargets[0]);
                        else if (Input.GetKeyUp(KeyCode.Alpha2)) AttackTarget(potentialTargets[1]);
                        else if (Input.GetKeyUp(KeyCode.Alpha3)&& potentialTargets.Count >2) AttackTarget(potentialTargets[2]);
                    }
                    if (Input.GetKeyUp(KeyCode.Alpha1)) SelectNewSkill(0);
                    if (Input.GetKeyUp(KeyCode.Alpha2)) SelectNewSkill(1);
                    if (Input.GetKeyUp(KeyCode.Alpha3)) SelectNewSkill(2);
                    if (Input.GetKeyUp(KeyCode.Alpha4)) SelectNewSkill(3);
                    if (Input.GetKeyUp(KeyCode.Alpha5)) SelectNewSkill(4);
                    if (Input.GetKeyUp(KeyCode.Alpha6)) SelectNewSkill(5);
                    if (Input.GetKeyUp(KeyCode.I) || Input.GetKeyUp(KeyCode.B)) source.player.OpenInventory();
                    if (Input.GetKeyUp(KeyCode.C)) source.player.OpenCharacter();
                    if (Input.GetKeyUp(KeyCode.D))
                    {
                        source.legs.MoveToTile(FindTile.instance.Right(GameManager.instance.player.location));
                    }
                    if (Input.GetKeyUp(KeyCode.A))
                    {
                        source.legs.MoveToTile(FindTile.instance.Left(GameManager.instance.player.location));
                    }
                    if (Input.GetKeyUp(KeyCode.W))
                    {
                        source.legs.MoveToTile(FindTile.instance.Up(GameManager.instance.player.location));
                    }
                    if (Input.GetKeyUp(KeyCode.S))
                    {
                        source.legs.MoveToTile(FindTile.instance.Down(GameManager.instance.player.location));
                    }
                    if (Input.GetKeyUp(KeyCode.E))
                    {
                        if(source.casting) source.Cast();
                        else source.decisions.RightHandPress();                      
                    }
                    if (Input.GetKeyUp(KeyCode.Q))
                    {
                        source.decisions.LeftHandPress();
                    }
                    if (Input.GetKeyUp(KeyCode.F))
                    {
                        foreach (Item i in Dungeon.instance.currentFloor.currentRoom.items.ToList())
                        {
                            if (source.location == i.location) i.PickUp();
                        }
                        foreach (Item i in Dungeon.instance.currentFloor.currentRoom.terrain.ToList())
                        {
                            if (i.player) i.Interact();
                        }
                    }
                    if (source.location.cost == 100)
                    {
                        if (Dungeon.instance.currentFloor.currentRoom.entrances[0] == source.location)
                        {
                            source.transform.position = new Vector2(source.transform.position.x, (Dungeon.instance.currentFloor.currentRoom.neighbors[0].entrances[1].y + 1));
                            Dungeon.instance.currentFloor.CurrentRoom(Dungeon.instance.currentFloor.currentRoom.neighbors[0]);
                        }
                        else if (Dungeon.instance.currentFloor.currentRoom.entrances[1] == source.location)
                        {
                            source.transform.position = new Vector2(source.transform.position.x, (Dungeon.instance.currentFloor.currentRoom.neighbors[1].entrances[0].y - 1));
                            Dungeon.instance.currentFloor.CurrentRoom(Dungeon.instance.currentFloor.currentRoom.neighbors[1]);
                        }
                        else if (Dungeon.instance.currentFloor.currentRoom.entrances[2] == source.location)
                        {
                            source.transform.position = new Vector2((Dungeon.instance.currentFloor.currentRoom.neighbors[2].entrances[3].x + 1), source.transform.position.y);
                            Dungeon.instance.currentFloor.CurrentRoom(Dungeon.instance.currentFloor.currentRoom.neighbors[2]);
                        }
                        else if (Dungeon.instance.currentFloor.currentRoom.entrances[3] == source.location)
                        {
                            source.transform.position = new Vector2((Dungeon.instance.currentFloor.currentRoom.neighbors[3].entrances[2].x - 1), source.transform.position.y);
                            Dungeon.instance.currentFloor.CurrentRoom(Dungeon.instance.currentFloor.currentRoom.neighbors[3]);
                        }
                        GameManager.instance.FindLocation();
                    }
                    if (Input.GetMouseButtonDown(0))
                    {
                        mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
                        location = Return.Location(Convert.ToInt32(Math.Round(mousePos.x)), Convert.ToInt32(Math.Round(mousePos.y)), Dungeon.instance.currentFloor.currentRoom.tileList);
                        if (looking)
                        {
                            foreach (Item i in Dungeon.instance.currentFloor.currentRoom.items)
                            {
                                if (i.location == location)
                                {
                                    foreach (string s in i.flavor) CombatLog.instance.UpdateLog(s);
                                    looking = false;
                                }
                            }
                            foreach (Item s in Dungeon.instance.currentFloor.currentRoom.staticObjects)
                            {
                                if (s.location == location)
                                {
                                    foreach (string st in s.flavor) CombatLog.instance.UpdateLog(st);
                                    looking = false;
                                }
                            }
                            foreach (Agent a in Dungeon.instance.currentFloor.currentRoom.agentList)
                            {
                                if (a.location == location)
                                {
                                    foreach (string s in a.flavor)
                                    {
                                        CombatLog.instance.UpdateLog(s);
                                        looking = false;
                                    }
                                }
                            }
                            foreach (Item i in Dungeon.instance.currentFloor.currentRoom.terrain)
                            {
                                if (i.location == location)
                                {
                                    foreach (String s in i.terrain.description) CombatLog.instance.UpdateLog(s);
                                    looking = false;
                                }
                            }
                            if (looking)
                            {
                                foreach (Location l in Dungeon.instance.currentFloor.currentRoom.tileList)
                                {
                                    if (l == location)
                                    {
                                        CombatLog.instance.UpdateLog(l.description);
                                        looking = false;
                                    }
                                }
                            }
                        }
                        if (potentialTargets.Count > 0)
                        {
                            CombatLog.instance.Clean();
                            foreach (Agent a in potentialTargets.ToList())
                            {
                                if (a.location == location)
                                {
                                    AttackTarget(a);
                                }
                            }
                        }
                    }
                }
            }
                   
        }  
        else
        {            
            if(source != null)
            {
                if (source.player.box.isActiveAndEnabled)
                {
                    if (Input.GetKeyUp(KeyCode.I)|| Input.GetKeyUp(KeyCode.B)) source.player.CloseShop();
                    else if (Input.GetKeyUp(KeyCode.C)) source.player.OpenCharacter();
                }
                else if (source.player.box3.isActiveAndEnabled)
                {
                    if (Input.GetKeyUp(KeyCode.I) || Input.GetKeyUp(KeyCode.B)) source.player.OpenInventory();
                    else if (Input.GetKeyUp(KeyCode.C)) source.player.CloseCharacter();
                }
            }            
        }
    }

    private void AttackTarget(Agent a)
    {
        CombatLog.instance.Clean();
        source.target = a;
        if (loadHead) Action.instance.Spell(source, a, loadSkill);
        else if (loadLegs) Action.instance.LegAttack(source, a, loadSkill);
        else if (loadSkill.type == SkillType.Spell) Action.instance.Spell(source, source.target, loadSkill);
        else Action.instance.Weapon(source, loadArm, a, loadWeapon, loadSkill);
        potentialTargets.Clear();
        GameManager.instance.EndTurn();
    }

    private void SelectNewSkill(int v)
    {
        if (rightHandSelect)
        {
            if (source.player.dropDownList[1].options.Count >= v) source.player.dropDownList[1].value = v;
            source.player.dropDownList[1].Hide();
        }
        else
        {
            if (source.player.dropDownList[0].options.Count >= v) source.player.dropDownList[0].value = v;
            source.player.dropDownList[0].Hide();
        }
    }
}
