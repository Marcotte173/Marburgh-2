using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Projectile : MonoBehaviour
{
    public Agent target;
    public float distance;
    public float speed;
    private void Update()
    {
        if(target != null)
        {
            transform.right = target.transform.position - transform.position;
            transform.position = Vector2.MoveTowards(transform.position, target.transform.position, speed * Time.deltaTime);
            distance = Vector2.Distance(transform.position, target.transform.position);
            if (distance < 0.3f)
            {
                gameObject.SetActive(false);
            }
        }   
        else gameObject.SetActive(false);
    }
}
