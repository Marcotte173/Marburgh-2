using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Floor : MonoBehaviour
{
    public List<Room> rooms;
    public List<Room> builtRooms;
    public Room room;
    public int floorNumber;
    public Room currentRoom;
    public string floorName;
    public Room heal;
    public Room shop;
    public int shopRoll;
    public int healingRoll;
    public int libraryRoll;
    public int kitchenRoll;
    public List<int> roomList;

    internal void MakeRooms(int roomsOnThisFloor)
    {
        for (int y = 1; y < 6; y++)
        {
            for (int x = 1; x < 6; x++)
            {
                Room newRoom = Instantiate(room, transform);
                rooms.Add(newRoom);
                newRoom.x = x;
                newRoom.y = y;
                newRoom.transform.position = new Vector2(0, 0);
                newRoom.name = $"Dungeon room {newRoom.x} , {newRoom.y}";
            }
        }
        //Create Room Neighbors
        foreach (Room l in rooms)
        {
            foreach (Room loc in rooms)
            {
                if (loc.x == l.x + 1 && loc.y == l.y) l.neighbors[2] = loc;
                if (loc.x == l.x - 1 && loc.y == l.y) l.neighbors[3] = loc;
                if (loc.x == l.x && loc.y == l.y + 1) l.neighbors[0] = loc;
                if (loc.x == l.x && loc.y == l.y - 1) l.neighbors[1] = loc;
            }
        }
        roomList = new List<int> { };
        for (int i = 2; i < roomsOnThisFloor - 2; i++) roomList.Add(i);
        shopRoll = MakeSpecialRoom();
        healingRoll = MakeSpecialRoom();
        libraryRoll = MakeSpecialRoom();
        kitchenRoll = MakeSpecialRoom();
        //Make First Room 
        currentRoom = rooms[12];       
        currentRoom.CreateBasicRoom(0);
        //Start Making rooms from the first        
        while (builtRooms.Count < roomsOnThisFloor)
        {
            int neighborRoll = Return.Int(0, 4);
            Room buildRoom = builtRooms[Return.Int(0, builtRooms.Count)];            
            Room nextRoom = buildRoom.neighbors[neighborRoll];
            if (nextRoom != null && !builtRooms.Contains(nextRoom))
            {
                //Right Now Basic Rooms, But eventually many different Rooms
                CreateBasicRoom(nextRoom, buildRoom, neighborRoll);
            }
        }
        builtRooms[builtRooms.Count - 1].stairDown = true;
        //Make sure only the current room is displayed
        foreach (Room g in rooms) GameManager.instance.TurnOff(g.gameObject);
        GameManager.instance.TurnOn(currentRoom.gameObject);
        currentRoom.agentList.Clear();
        currentRoom.agentList.Add(GameManager.instance.player);
        foreach (Agent a in currentRoom.enemyList)
        {
            if (!a.dead)
            {
                currentRoom.agentList.Add(a);
                a.transform.position = new Vector2(a.GetComponent<Enemy>().startingLocation.x, a.GetComponent<Enemy>().startingLocation.y);
            }
        }
        GameManager.instance.FindLocation();
        GameManager.instance.UpdateSprites();
        CombatLog.instance.UpdateLog("");
        foreach (Room r in builtRooms)
        {
            for (int i = 0; i < 4; i++)
            {
                foreach(Room ro in builtRooms)
                {
                    if (r.neighbors[i] == ro && r.entrances[i] !=null)
                    {
                        r.connectedRooms[i] = r.neighbors[i];
                        break;
                    }
                }
                
            }
        }        
        foreach (Room r in builtRooms) r.floor = this;
        foreach (Room r in builtRooms) r.Populate();
        if (builtRooms[builtRooms.Count - 1].connectedRooms[0] != null) builtRooms[builtRooms.Count - 1].connectedRooms[0].LockedDoor(builtRooms[builtRooms.Count - 1].connectedRooms[0].entrances[1]);
        else if (builtRooms[builtRooms.Count - 1].connectedRooms[1] != null) builtRooms[builtRooms.Count - 1].connectedRooms[1].LockedDoor(builtRooms[builtRooms.Count - 1].connectedRooms[1].entrances[0]);
        else if (builtRooms[builtRooms.Count - 1].connectedRooms[2] != null) builtRooms[builtRooms.Count - 1].connectedRooms[2].LockedDoor(builtRooms[builtRooms.Count - 1].connectedRooms[2].entrances[3]);
        else if (builtRooms[builtRooms.Count - 1].connectedRooms[3] != null) builtRooms[builtRooms.Count - 1].connectedRooms[3].LockedDoor(builtRooms[builtRooms.Count - 1].connectedRooms[3].entrances[2]);
    }

            private int MakeSpecialRoom()
            {
                int random = Return.Int(0, roomList.Count);
                int x = roomList[random];
                roomList.RemoveAt(random);
                return x;
            }

            public void CurrentRoom(Room c)
            {
                currentRoom = c;
                //Make sure only the current room is displayed
                foreach (Room g in rooms) GameManager.instance.TurnOff(g.gameObject);
                GameManager.instance.TurnOn(currentRoom.gameObject);
                currentRoom.Enter();
            }

            void CreateBasicRoom(Room nextRoom, Room buildRoom, int neighborRoll)
            {

                if (neighborRoll == 0)
                {
                    int roll = Return.Int(1, 3);
                    if (roll == 1)
                    {
                        buildRoom.BuildEntrance(1);
                        nextRoom.CreateBasicRoom(6);
                    }
                    else
                    {
                        buildRoom.BuildEntrance(2);
                        nextRoom.CreateBasicRoom(5);
                    }
                }
                else if (neighborRoll == 2)
                {
                    int roll = Return.Int(3, 5);
                    if (roll == 3)
                    {
                        buildRoom.BuildEntrance(3);
                        nextRoom.CreateBasicRoom(8);
                    }
                    else
                    {
                        buildRoom.BuildEntrance(4);
                        nextRoom.CreateBasicRoom(7);
                    }
                }
                else if (neighborRoll == 1)
                {
                    int roll = Return.Int(5, 7);
                    if (roll == 5)
                    {
                        buildRoom.BuildEntrance(5);
                        nextRoom.CreateBasicRoom(2);
                    }
                    else
                    {
                        buildRoom.BuildEntrance(6);
                        nextRoom.CreateBasicRoom(1);
                    }
                }
                else
                {
                    int roll = Return.Int(7, 9);
                    if (roll == 7)
                    {
                        buildRoom.BuildEntrance(7);
                        nextRoom.CreateBasicRoom(4);
                    }
                    else
                    {
                        buildRoom.BuildEntrance(8);
                        nextRoom.CreateBasicRoom(3);
                    }
                }
            }
        }
