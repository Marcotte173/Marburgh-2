using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public enum ArmUse {None,Both,Left,Right}
public class Player : MonoBehaviour
{
    public Agent source;
    public ArmUse lastArmUsed;
    public bool leftArm;
    public bool rightArm;
    public GameObject recap;
    public int damageTaken;
    public int damageDone;
    public int monstersSlain;
    public Text recapText;
    public int gold;
    public List<Text> text;
    public List<Dropdown> dropDownList;
    public Image box;
    public Image box2;
    public Image box3;
    public Image characterScreenRightWeapon;
    public Image characterScreenLefttWeapon;
    public List<Item> inventory;
    public List<GameObject> inventoryAnchor;
    public List<Item> shop;
    public List<GameObject> shopAnchor;
    public Item item;
    public Canvas inventoryCanvas;
    public GameObject itemObject;
    public Text bag;
    public Text character;
    public List<Skill> skills;

    private void Awake()
    {
        for (int i = 0; i < skills.Count; i++)
        {
            skills[i] = Instantiate(skills[i]);
        }
    }
    public void Death()
    {
        PlayerInput.instance.combatOn = false;
        GameManager.instance.TurnOffButtons();
        GameManager.instance.TurnOn(recap);
        recapText.text = "You have died!\nNot to worry, you can try again";
        recapText.text += $"\n\n\nFloors: {Dungeon.instance.currentFloor.floorNumber}";
        recapText.text += $"\nWhat killed you: {source.whoHitMeLast}";
        recapText.text += $"\nMonsters Slain: {monstersSlain}";
        recapText.text += $"\nDamage Done: {damageDone}";
        recapText.text += $"\nDamage Taken: {damageTaken}";
    }
    internal void Win()
    {
        PlayerInput.instance.combatOn = false;
        GameManager.instance.TurnOffButtons();
        GameManager.instance.TurnOn(recap);
        recapText.text = "You win the game!\nLet me know in the comments what you think\nThat is, unless you didn't like it\nYou keep that shit to yourself";
        recapText.text += $"\n\n\nFloors: {Dungeon.instance.currentFloor.floorNumber}";
        recapText.text += $"\nWhat killed you: {source.whoHitMeLast}";
        recapText.text += $"\nMonsters Slain: {monstersSlain}";
        recapText.text += $"\nDamage Done: {damageDone}";
        recapText.text += $"\nDamage Taken: {damageTaken}";
    }
    public void CreateInventory()
    {
        GameManager.instance.TurnOn(box.gameObject);
        for (int i = 0; i < 16; i++)
        {
            Item it = Instantiate(item, itemObject.transform);
            inventory.Add(it);
            inventory[i].ChangeInventorySprite();
            it.GetComponent<RectTransform>().sizeDelta = new Vector2(100, 100);
            it.inventory = i + 1;
            it.name = (i + 1).ToString();
            float x = inventoryAnchor[i].transform.position.x;
            float y = inventoryAnchor[i].transform.position.y;
            it.anchorPosition = new Vector2(x, y);
            it.transform.position = it.anchorPosition;
            it.anchorPosition = new Vector2(x, y + 10);
        }
        Weapon lf = Instantiate(ItemList.instance.leftFist, inventory[13].transform);
        inventory[13].weapon = lf;
        Weapon rf = Instantiate(ItemList.instance.rightFist, inventory[14].transform);
        inventory[14].weapon = rf;
        GameManager.instance.TurnOff(box.gameObject);
    }
    internal void OpenCharacter()
    {
        GameManager.instance.TurnOn(box3.gameObject);
        GameManager.instance.TurnOff(box2.gameObject);
        GameManager.instance.TurnOff(box.gameObject);
        PlayerInput.instance.combatOn = false;
    }

    public void CloseCharacter()
    {
        GameManager.instance.TurnOff(box3.gameObject);
        GameManager.instance.TurnOff(box2.gameObject);
        GameManager.instance.TurnOff(box.gameObject);
        GameManager.instance.TurnOff(itemObject.gameObject);
        PlayerInput.instance.combatOn = true;
    }

    public void CreateShop()
    {
        GameManager.instance.TurnOn(box2.gameObject);
        for (int i = 0; i < 6; i++)
        {
            Item it = Instantiate(item, itemObject.transform);
            shop.Add(it);
            shop[i].ChangeInventorySprite();
            it.GetComponent<RectTransform>().sizeDelta = new Vector2(100, 100);
            it.inventory = i + 1;
            it.name = (i + 1).ToString();
            float x = shopAnchor[i].transform.position.x;
            float y = shopAnchor[i].transform.position.y;
            it.anchorPosition = new Vector2(x, y);
            it.transform.position = it.anchorPosition;
            it.anchorPosition = new Vector2(x, y + 10);
        }
        inventory[8].name = "Head";
        inventory[9].name = "Body";
        inventory[10].name = "Left Arm";
        inventory[11].name = "Right Arm";
        inventory[12].name = "Legs";
        shop[5].drop = ItemList.instance.sell;
        inventory.Add(shop[5]);
        shop.Remove(shop[5]);
        GameManager.instance.TurnOff(box2.gameObject);
    }

    

    public void CloseInventory()
    {
        GameManager.instance.TurnOff(box.gameObject);
        GameManager.instance.TurnOff(box2.gameObject);
        GameManager.instance.TurnOff(itemObject.gameObject);
        PlayerInput.instance.combatOn = true;
    }
    public void OpenCharacterButton()
    {
        if (box3.isActiveAndEnabled) CloseCharacter();
        else OpenCharacter();
    }

    public void OpenInventoryButton()
    {
        if (box.isActiveAndEnabled) CloseInventory();
        else OpenInventory();
    }
    public void OpenInventory()
    {
        GameManager.instance.TurnOn(box.gameObject);
        GameManager.instance.TurnOff(box3.gameObject);
        GameManager.instance.TurnOn(itemObject.gameObject);
        foreach (Item i in shop) GameManager.instance.TurnOff(i.gameObject);
        GameManager.instance.TurnOff(inventory[16].gameObject);
        PlayerInput.instance.combatOn = false;
        GameManager.instance.UpdateSprites();
    }
    public void CloseShop()
    {
        GameManager.instance.TurnOff(box2.gameObject);
        CloseInventory();
        CloseCharacter();
        PlayerInput.instance.combatOn = true;
    }
    public void OpenShop()
    {
        OpenInventory();
        GameManager.instance.TurnOn(inventory[16].gameObject);
        GameManager.instance.TurnOn(box2.gameObject);
        foreach (Item i in shop) GameManager.instance.TurnOn(i.gameObject);
        PlayerInput.instance.combatOn = false;
        GameManager.instance.UpdateSprites();
    }

    internal void ShopStock()
    {
        int type = Return.Int(0, 5);
        if (type < 2)
        {
            for (int i = 0; i < 5; i++)
            {
                shop[i].weapon = GameManager.instance.CreateNewWeapon(ItemList.instance.shopWeapon1[Return.Int(0, ItemList.instance.shopWeapon1.Count)]);
                shop[i].weapon.shop = true;
            }
        }
        else if (type < 4)
        {
            for (int i = 0; i < 5; i++)
            {
                shop[i].armor = GameManager.instance.CreateNewArmor(ItemList.instance.shopArmor1[Return.Int(0, ItemList.instance.shopArmor1.Count)]);
                shop[i].armor.shop = true;
            }
        }
        else
        {
            for (int i = 0; i < 5; i++)
            {
                shop[i].drop = GameManager.instance.CreateNewDrop(ItemList.instance.shopDrop1[Return.Int(0, ItemList.instance.shopDrop1.Count)]);
                shop[i].drop.shop = true;
            }
        }
    }
}
