using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dungeon : MonoBehaviour
{
    public static Dungeon instance;
    public List<Floor> floors;    
    public Floor floor;
    public Floor currentFloor;

    private void Awake()
    {
        instance = this;
    }

    public void CreateWorld()
    {
        MakeFloor();
    }

    private void MakeFloor()
    {
        Floor f = Instantiate(floor, GameManager.instance.dungeonObject.transform);
        f.floorNumber = floors.Count + 1;
        f.transform.position = new Vector2(0, 0);
        f.floorName = f.name = "Floor " + (f.floorNumber);
        floors.Add(f);
        currentFloor = f;
        f.MakeRooms(10);        
        foreach (Floor g in floors) GameManager.instance.TurnOff(g.gameObject);
        GameManager.instance.TurnOn(f.gameObject);
    }
}
