﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class Head : Body
{
    public int intelligence;
    public List<Skill> knownActions;
    public List<Skill> headActions;
    public Dropdown dropDown;
    public Button button;
    public Text text;
}
