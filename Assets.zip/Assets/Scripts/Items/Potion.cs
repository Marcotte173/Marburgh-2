using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Potion : MonoBehaviour
{
    public static Potion instance;
    public List<Sprite> potionColor;
    public List<Drop> potions;
    public List<bool> potionDiscovered;
    public List<string> potionName;
    public Drop potion;
    private void Start()
    {
        instance = this;
        for (int i = 0; i < potionName.Count; i++)
        {
            MakePotions(i);
        }
    }
    private void MakePotions(int i)
    {
        Drop p = Instantiate(potion);
        int c1 = Return.Int(0, potionColor.Count);
        p.sprite = potionColor[c1];
        potionColor.Remove(potionColor[c1]);
        p.dropName = "Unidentified Potion";
        p.name = potionName[i] + " Unidentified";
        ItemList.instance.shopDrop1.Add(p);
        potions.Add(p);
        p.level = i;
        potionDiscovered.Add(false);
    }

    public void UsePotion(int level, Body b)
    {
        switch (level)
        {
            case 0:
                HealthPotion(b);
                break;
            case 1:
                WitheringPotion(b);
                break;
            case 2:
                IntellectPotion(b);
                break;
            case 3:
                CoordinationPotion(b);
                break;
            case 4:
                AtaxiPotion(b);
                break;
            case 5:
                StrengthPotion(b);
                break;
            case 6:
                WeaknessPotion(b);
                break;
        }
    }

    private void WeaknessPotion(Body b)
    {
        Apply(b);
        if (b == GameManager.instance.player.head || b == GameManager.instance.player.body || b == GameManager.instance.player.legs)
        {
            int arm = Return.Int(0, 2);
            CombatLog.instance.Clean();
            CombatLog.instance.UpdateLog("You drink the potion");
            CombatLog.instance.UpdateLog("You feel Weaker");
            if (Return.Int(0, 4) == 0)
            {
                if (arm == 0) GameManager.instance.player.leftArm.Strength(-1);
                else if (arm == 1) GameManager.instance.player.rightArm.Strength(-1);
            }
            else
            {
                if (arm == 0) GameManager.instance.player.leftArm.Strength(-2);
                else if (arm == 1) GameManager.instance.player.rightArm.Strength(-2);
            }
        }
        else
        {
            CombatLog.instance.Clean();
            CombatLog.instance.UpdateLog($"You apply the potion to your {b.bodyName}");
            CombatLog.instance.UpdateLog("The contents are slowly absorbed by your skin");
            if (b == GameManager.instance.player.leftArm) GameManager.instance.player.leftArm.Strength(-1);
            else if (b == GameManager.instance.player.rightArm) GameManager.instance.player.rightArm.Strength(-1);
        }
        Identify(6);
    }

    private void StrengthPotion(Body b)
    {
        Apply(b);
        if (b == GameManager.instance.player.head || b == GameManager.instance.player.body || b == GameManager.instance.player.legs)
        {
            int arm = Return.Int(0, 2);
            CombatLog.instance.Clean();
            CombatLog.instance.UpdateLog("You drink the potion");
            CombatLog.instance.UpdateLog("You feel STRONGER");
            if (Return.Int(0, 4) == 0)
            {
                if (arm == 0) GameManager.instance.player.leftArm.Strength(1);
                else if (arm == 1) GameManager.instance.player.rightArm.Strength(1);
            }
            else
            {
                if (arm == 0) GameManager.instance.player.leftArm.Strength(2);
                else if (arm == 1) GameManager.instance.player.rightArm.Strength(2);
            }
        }
        else
        {
            CombatLog.instance.Clean();
            CombatLog.instance.UpdateLog($"You apply the potion to your {b.bodyName}");
            CombatLog.instance.UpdateLog("The contents are slowly absorbed by your skin");
            if (b == GameManager.instance.player.leftArm) GameManager.instance.player.leftArm.Strength(1);
            else if (b == GameManager.instance.player.rightArm) GameManager.instance.player.rightArm.Strength(1);
        }
        Identify(5);
    }

    private void AtaxiPotion(Body b)
    {
        Apply(b);
        if (b == GameManager.instance.player.head || b == GameManager.instance.player.body)
        {
            int arm = Return.Int(0, 2);
            CombatLog.instance.Clean();
            CombatLog.instance.UpdateLog("You drink the potion");
            CombatLog.instance.UpdateLog("You feel clumsy and slow");
            if (Return.Int(0, 4) == 0)
            {
                if (arm == 0) GameManager.instance.player.leftArm.Coordinate(-1);
                else if (arm == 1) GameManager.instance.player.rightArm.Coordinate(-1);
            }
            else
            {
                if (arm == 0) GameManager.instance.player.leftArm.Coordinate(-2);
                else if (arm == 1) GameManager.instance.player.rightArm.Coordinate(-2);
            }
        }
        else
        {
            CombatLog.instance.Clean();
            CombatLog.instance.UpdateLog($"You apply the potion to your {b.bodyName}");
            CombatLog.instance.UpdateLog("The contents are slowly absorbed by your skin");
            if (b == GameManager.instance.player.leftArm) GameManager.instance.player.leftArm.Coordinate(-1);
            else if (b == GameManager.instance.player.rightArm) GameManager.instance.player.rightArm.Coordinate(-1);
            else GameManager.instance.player.legs.Movement(-1);
        }        
        Identify(4);
    }

    private void CoordinationPotion(Body b)
    {
        Apply(b);
        if (b == GameManager.instance.player.head || b == GameManager.instance.player.body)
        {
            int arm = Return.Int(0, 2);
            CombatLog.instance.Clean();
            CombatLog.instance.UpdateLog("You drink the potion");
            CombatLog.instance.UpdateLog("You feel energized");
            if (Return.Int(0, 4) == 0)
            {
                if (arm == 0) GameManager.instance.player.leftArm.Coordinate(2);
                else if (arm == 1) GameManager.instance.player.rightArm.Coordinate(2);
            }
            else
            {
                if (arm == 0) GameManager.instance.player.leftArm.Coordinate(1);
                else if (arm == 1) GameManager.instance.player.rightArm.Coordinate(1);
            }
        }
        else
        {
            CombatLog.instance.Clean();
            CombatLog.instance.UpdateLog($"You apply the potion to your {b.bodyName}");
            CombatLog.instance.UpdateLog("The contents are slowly absorbed by your skin");
            if (b == GameManager.instance.player.leftArm) GameManager.instance.player.leftArm.Coordinate(1);
            else if (b == GameManager.instance.player.rightArm) GameManager.instance.player.rightArm.Coordinate(1);
            else GameManager.instance.player.legs.Movement(1);
        }        
        Identify(3);
    }
    private void IntellectPotion(Body b)
    {
        Apply(b);
        CombatLog.instance.Clean();
        CombatLog.instance.UpdateLog("You drink the potion");
        CombatLog.instance.UpdateLog("You sit and think");
        CombatLog.instance.UpdateLog("Things start to make more sense");
        GameManager.instance.player.head.intelligence++;
        Identify(2);
    }

    private void WitheringPotion(Body b)
    {
        Apply(b);
        if (b == GameManager.instance.player.head)
        {
            List<Body> need = new List<Body> { GameManager.instance.player.head, GameManager.instance.player.body, GameManager.instance.player.leftArm, GameManager.instance.player.rightArm, GameManager.instance.player.legs };
            Return.SortHave(need);
            CombatLog.instance.Clean();
            CombatLog.instance.UpdateLog("You drink the potion");
            CombatLog.instance.UpdateLog("You feel pain, like liquid fire is running through your veins");
            if (Return.Int(0, 4) == 0)
            {
                need[0].ChangeHealth((int)b.status + 2, false);
                need[1].ChangeHealth((int)b.status + 2,false) ;
                need[2].ChangeHealth((int)b.status + 2, false);
            }
            else
            {
                need[0].ChangeHealth((int)b.status + 3, false);
            }
        }
        else
        {
            if (Return.TheStatus(b.hp, b.maxHp) == Status.Destroyed)
            {
                CombatLog.instance.Clean();
                CombatLog.instance.UpdateLog("You drink the potion");
                CombatLog.instance.UpdateLog("The potion doesn't seem to have any efect");
            }
            else b.ChangeHealth((int)b.status + 1, false);
        }
        Identify(1);
    }

    private void HealthPotion(Body b)
    {
        Apply(b);
        if(b == GameManager.instance.player.head)
        {
            List<Body> need = new List<Body> { GameManager.instance.player.head, GameManager.instance.player.body, GameManager.instance.player.leftArm, GameManager.instance.player.rightArm, GameManager.instance.player.legs };
            if (NoHealNeeded())
            {
                CombatLog.instance.Clean();
                CombatLog.instance.UpdateLog("You drink the potion");
                CombatLog.instance.UpdateLog("The potion doesn't seem to have any efect");
            }
            else
            {
                Return.SortNeed(need);
                CombatLog.instance.Clean();
                CombatLog.instance.UpdateLog("You drink the potion");
                CombatLog.instance.UpdateLog("You feel the lifegiving potion running through your veins");
                if (Return.Int(0, 4) == 0)
                {
                    need[0].ChangeHealth((int)b.status - 2, true);
                    if ((int)need[1].status > 2) need[1].ChangeHealth((int)b.status - 1, true);
                    if ((int)need[2].status > 2) need[2].ChangeHealth((int)b.status - 1, true);
                }
                else
                {
                    need[0].ChangeHealth((int)b.status - 4, true);
                }
            }            
        }           
        else
        {
            if (Return.TheStatus(b.hp, b.maxHp) == Status.Undamaged)
            {
                CombatLog.instance.Clean();
                CombatLog.instance.UpdateLog("You drink the potion");
                CombatLog.instance.UpdateLog("The potion doesn't seem to have any efect");
            }
            else b.ChangeHealth((int)b.status - 1, true);
        }        
        Identify(0);
    }

    private bool NoHealNeeded()
    {
        if (GameManager.instance.player.head.status != Status.Undamaged) return false;
        if (GameManager.instance.player.body.status != Status.Undamaged) return false;
        if (GameManager.instance.player.leftArm.status != Status.Undamaged) return false;
        if (GameManager.instance.player.rightArm.status != Status.Undamaged) return false;
        if (GameManager.instance.player.body.status != Status.Undamaged) return false;
        return true;
    }

    private void Apply(Body b)
    {
        if (b == GameManager.instance.player.head)
        {
            CombatLog.instance.Clean();
            CombatLog.instance.UpdateLog("You drink the potion");
        }
        else
        {
            CombatLog.instance.Clean();
            CombatLog.instance.UpdateLog($"You apply the potion to your {b.bodyName}");
            CombatLog.instance.UpdateLog("The contents are slowly absorbed by your skin");
        }
    }

    public void Identify(int level)
    {
        potions[level].dropName = potionName[level];
        potions[level].name = potionName[level];
        foreach(Item i in GameManager.instance.player.player.shop)
        {
            if(i.drop != null)
            {
                if(i.drop.level == level)
                {
                    i.drop.dropName = potions[level].dropName;
                    i.drop.name = potions[level].name;
                }
            }
        }
        foreach(Floor f in Dungeon.instance.floors)
        {
            foreach(Room r in f.rooms)
            {
                foreach(Item i in r.items)
                {
                    if (i.drop != null)
                    {
                        if (i.drop.level == level)
                        {
                            i.drop.dropName = potions[level].dropName;
                            i.drop.name = potions[level].name;
                        }
                    }
                }
            }
        }
    }
}
