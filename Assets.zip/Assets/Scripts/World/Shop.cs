using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shop : MonoBehaviour
{
    public static Shop instance;
    public void OpenShop()
    {

    }
    public void CloseShop()
    {

    }
    private void Awake()
    {
        instance = this;        
    }
}
